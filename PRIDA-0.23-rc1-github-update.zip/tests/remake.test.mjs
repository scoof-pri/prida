import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from 'three';
import { Arena, initPhysics } from '../src/simulation.js';
import { createWorld, seededRandom } from '../src/world.js';
import { WEAPONS, makeItem } from '../src/items.js';
import { chestGeometry, ChestField } from '../src/chests.js';
import { isDryLand, coastDistance, ISLAND_TOWNS } from '../src/island.js';
import { groundHeight, terrainMesh } from '../src/terrain.js';
import { castMap } from '../src/raycast.js';
import { cellGrid, chipMicro, encodeMicro, decodeMicro, cellRects } from '../src/cells.js';
import { syncInteractions, interactionNear } from '../src/interactions.js';
import { makeOperator, OPERATOR_CLIPS } from '../src/operators.js';
import { makeCreature } from '../src/creatures.js';
import { detailedWeapon } from '../src/weapon-rig.js';
import { readFriends, validFriendCode } from '../src/friends.js';
await initPhysics();
function arena(options={}){return new Arena({random:seededRandom(321),...options});}
function player(a,id='p',x=0,z=0,y=.02){const p=a.addPlayer(id,id);a.place(p,x,z,y);p.shield=0;p.cooldown=0;p.angle=0;p.pitch=0;return p;}
function arm(a,p,name){const i=WEAPONS.findIndex(w=>w.name===name);p.slots[1]=makeItem(i);p.slot=1;a.syncHeld(p);return WEAPONS[i];}
function ticks(a,n,p,input={}){for(let i=0;i<n;i++){if(p)a.input(p.id,input);a.step(1/60);}}

test('chest: body has solid front and interior faces, opaque depth-writing materials',()=>{
  const scene=new T.Scene(),field=new ChestField(scene);
  assert.equal(field.meshes.length,4);
  for(const m of [field.wood,field.metal]){assert.equal(m.transparent,false);assert.equal(m.opacity,1);assert.equal(m.depthWrite,true);}
  const mesh=new T.Mesh(chestGeometry(),new T.MeshBasicMaterial({side:T.FrontSide}));mesh.updateMatrixWorld(true);
  for(const [origin,dir] of [[new T.Vector3(0,.4,2),new T.Vector3(0,0,-1)],[new T.Vector3(0,.4,0),new T.Vector3(1,0,0)],[new T.Vector3(0,-1,0),new T.Vector3(0,1,0)]])assert.ok(new T.Raycaster(origin,dir).intersectObject(mesh).length,'solid chest surface');
  mesh.geometry.dispose();mesh.material.dispose();field.dispose();
});
test('chest: pool grows, rare tiers stay opaque, lid transforms remain finite through opening',()=>{
  const f=new ChestField(new T.Scene()),list=Array.from({length:175},(_,i)=>({id:'c'+i,x:i*2,y:0,z:0,loot:{r:i%5},opened:false}));
  f.update(list,.016);assert.equal(f.body.count,175);assert.ok(f.capacity>=175);
  for(const c of list)c.opened=true;
  for(let i=0;i<60;i++)f.update(list,1/60);
  assert.ok(f.slots.get('c0').open>.99);assert.ok(f.lid.instanceMatrix.array.every(Number.isFinite));
  f.update(list.slice(0,2),.1,c=>c.id==='c1');assert.equal(f.body.count,1);assert.equal(f.slots.size,2);f.dispose();
});
test('island: deterministic settlements, dry spawns/chests, distinct terrain and a physical bridge',()=>{
  const a=createWorld(88,'city'),b=createWorld(88,'city');
  assert.deepEqual(a.buildings.map(b=>[b.type,b.x,b.z]),b.buildings.map(b=>[b.type,b.x,b.z]));
  assert.deepEqual(a.chests,b.chests);assert.deepEqual(a.limit,{x:600,z:540});
  for(const p of ISLAND_TOWNS)assert.ok(a.pois.some(q=>q.name===p.name));
  assert.ok(a.obstacles.some(o=>o.part==='bridge'));assert.ok(a.maxTerrainHeight>25);
  for(const [x,z]of a.spawns)assert.ok(isDryLand(x,z,a,5));
  for(const c of a.chests)assert.ok(isDryLand(c.x,c.z,a));
  assert.ok(coastDistance(a.limit.x,a.limit.z,a)<0);assert.ok(groundHeight(a.limit.x,a.limit.z,a)<a.island.water);
  assert.ok(a.chests.some(c=>c.storey>0));assert.ok(a.chests.length<a.buildings.length*2);
});
test('island: coarse mesh and shared height sampler agree at every tested vertex',()=>{
  const m=createWorld(33,'city'),t=terrainMesh(m);assert.ok(t.vertices.every(Number.isFinite));
  for(let i=0;i<t.vertices.length;i+=3*277){const x=t.vertices[i],y=t.vertices[i+1],z=t.vertices[i+2];assert.ok(Math.abs(y-groundHeight(x,z,m))<.00002);}
});
test('island: buildings have dry level foundations and no new loot intersects interactive shafts',()=>{
  const m=createWorld(7,'city');for(const b of m.buildings)assert.ok(Math.abs(groundHeight(b.x,b.z,m))<.1,b.type);
  for(const c of m.chests){let hit=false;m.obstacles.grid.query(c.x-1,c.z-1,c.x+1,c.z+1,o=>{
    if(o.nocollide||o.y+o.h/2<(c.y||0)+.06||o.y-o.h/2>(c.y||0)+.85)return;
    if(Math.abs(c.x-o.x)<o.w/2+.60&&Math.abs(c.z-o.z)<o.d/2+.40)hit=true;
  });assert.equal(hit,false,c.id+' must fit its location');}
});
test('hand grenade: flies, bounces, waits for its fuse and explodes only once',()=>{
  const a=arena();try{const p=player(a),q=player(a,'q',20,0);p.cheats.god=true;arm(a,p,'GRENADE');p.pitch=-1.1;a.shoot(p);
    let bounced=false,was=-Infinity;for(let i=0;i<135;i++){const r=a.projectiles[0];a.stepProjectiles(1/60);if(r.vy>0&&was<0)bounced=true;was=r.vy;}
    assert.equal(a.projectiles.length,1);assert.ok(bounced);const r=a.projectiles[0];a.place(q,r.x+.7,r.z,Math.max(.02,r.y-.5));q.shield=0;
    for(let i=0;i<40;i++)a.stepProjectiles(1/60);
    assert.equal(a.projectiles.length,0);assert.ok(q.hp<100);assert.equal(a.drainEvents().filter(e=>e.type==='explosion'&&e.cause==='handgrenade').length,1);
  }finally{a.dispose();}
});
test('C4: capped at three, fourth does not consume ammo, owner-only arming and detonation',()=>{
  const a=arena();try{const p=player(a),q=player(a,'q',40,0);p.cheats.god=true;arm(a,p,'C4');
    for(let i=0;i<3;i++){p.slots[1].ammo=1;a.shoot(p);}p.slots[1].ammo=1;a.shoot(p);assert.equal(a.projectiles.length,3);assert.equal(p.slots[1].ammo,1);
    assert.equal(a.detonateCharges(p),0);for(let i=0;i<30;i++)a.stepProjectiles(1/60);
    assert.equal(a.detonateCharges(q),0);assert.equal(a.detonateCharges(p),3);assert.equal(a.projectiles.length,0);
    assert.equal(a.detonateCharges(p),0);
  }finally{a.dispose();}
});
test('C4: sticky position, lifetime and owner removal are bounded',()=>{
  const a=arena();try{const p=player(a);arm(a,p,'C4');p.pitch=-1.3;a.shoot(p);for(let i=0;i<100;i++)a.stepProjectiles(1/60);
    const r=a.projectiles[0];assert.ok(r.stuck);const at=[r.x,r.y,r.z];a.stepProjectiles(.1);assert.deepEqual([r.x,r.y,r.z],at);
    assert.doesNotThrow(()=>JSON.stringify(a.drainEvents()));r.life=.01;a.stepProjectiles(.02);assert.equal(a.projectiles.length,0);
    p.slots[1].ammo=1;a.shoot(p);a.removePlayer(p.id);assert.equal(a.projectiles.length,0);
  }finally{a.dispose();}
});
test('shield cell: completes, consumes one, caps shield and is cancelled by damage',()=>{
  const a=arena();try{const p=player(a);p.shieldHP=80;p.shieldCells=2;a.input(p.id,{shieldUse:true});a.step();assert.ok(p.shielding>0);
    ticks(a,130,p);assert.equal(p.shieldCells,1);assert.equal(p.shieldHP,100);
    p.shieldHP=0;a.input(p.id,{shieldUse:true});a.step();a.damage(null,p,1);assert.equal(p.shielding,0);assert.equal(p.shieldCells,1);
  }finally{a.dispose();}
});
test('shield: exact fractional absorption precedes armor, invalid damage is rejected',()=>{
  const a=arena();try{const p=player(a);p.shieldHP=10;a.damage(null,p,7.5);assert.equal(p.shieldHP,2.5);assert.equal(p.hp,100);
    a.damage(null,p,5);assert.equal(p.hp,97.5);assert.equal(p.shieldHP,0);
    for(const n of [NaN,Infinity,-10])a.damage(null,p,n);assert.equal(p.hp,97.5);
  }finally{a.dispose();}
});
test('loot: a player cannot pick a chest on another floor',()=>{
  const a=arena();try{const p=player(a),c=a.chests.find(c=>c.storey>0);a.place(p,c.x,c.z,0);assert.equal(a.openChest(p),false);
    a.place(p,c.x,c.z,c.y+.02);assert.equal(a.openChest(p),true);
  }finally{a.dispose();}
});
test('doors: moving collider blocks shots when shut and clears the doorway when open',()=>{
  const a=arena();try{const d=a.interactions.doors.find(d=>!d.storey),p=player(a);a.place(p,d.x,d.z+d.face*1.7,.02);d.target=0;
    a.interactions.step(.4);a.interactions.step(.4);assert.equal(d.open,0);
    const origin={x:d.x,y:1.3,z:d.z+d.face*1},dir={x:0,y:0,z:-d.face};assert.ok(castMap(origin,dir,1.8,a.map).distance<1.2);
    assert.equal(interactionNear(a.map,p)?.type,'door');assert.equal(a.interactions.use(p),true);for(let i=0;i<30;i++)a.interactions.step(1/60);
    assert.equal(d.open,1);assert.ok(castMap(origin,dir,1.8,a.map).distance>1.5);
    const client=createWorld(a.map.seed);syncInteractions(client,a.snapshot());const mirrored=client.interactiveDoors.find(v=>v.id===d.id);assert.equal(mirrored.open,1);
  }finally{a.dispose();}
});
test('doors: closing door reopens at the safety edge',()=>{
  const a=arena();try{const p=player(a),d=a.interactions.doors.find(d=>!d.storey);a.place(p,d.x,d.z,.02);d.target=0;a.interactions.step(.1);assert.equal(d.target,1);assert.equal(d.open,1);}finally{a.dispose();}
});
test('lift: moves a rider, closes gates, mirrors snapshots, and stops after structural destruction',()=>{
  const a=arena();try{const l=a.interactions.lifts[0];assert.ok(l);const p=player(a);a.place(p,l.x,l.z,.02);assert.equal(a.interactions.use(p),true);
    ticks(a,180,p);assert.ok(Math.abs(l.y-l.floors[1])<.001);assert.ok(Math.abs(p.y-l.y)<.1);
    const copy=createWorld(a.map.seed);syncInteractions(copy,a.snapshot());const other=copy.lifts.find(v=>v.id===l.id);assert.equal(other.y,l.y);assert.ok(Math.abs(other.platform.y-(l.y-.11))<.001);
    a.map.buildings[l.building].collapsed=true;a.interactions.step(.02);assert.ok(l.broken);assert.equal(a.colliders.has(l.platform),false);
  }finally{a.dispose();}
});
test('micro craters: rounded local carving is smaller than a coarse cell and serializes exactly',()=>{
  const o={x:0,y:1,z:0,w:2,h:2,d:.4,panel:1,color:0x999999};const point={x:0,y:1,z:.20},dir={x:0,y:0,z:-1};
  chipMicro(o,point,dir,18);const before=cellGrid(o).cols*cellGrid(o).rows;assert.equal(o.cellsAlive,before);
  const text=encodeMicro(o);assert.ok(text.length<64);assert.deepEqual(decodeMicro(text,o),o.microCells);
  const rects=cellRects(o);assert.ok(rects.some(r=>r.micro));const volume=rects.reduce((v,r)=>v+r.w*r.h*r.d,0);const whole=o.w*o.h*o.d;assert.ok(volume>whole*.95&&volume<whole);
});
test('railgun: damages a target behind one thin wall and respects its penetration limit',()=>{
  const a=arena();try{for(const b of a.bosses.list)b.hp=0;const p=player(a),q=player(a,'q',0,10);arm(a,p,'ARC LANCE');
    const wall={x:0,y:1.2,z:5,w:4,h:2.4,d:.4,part:'wall',panel:999991,hp:100,structural:false};a.addObs(wall);
    a.shoot(p);assert.ok(q.hp<100);assert.ok(a.drainEvents().some(e=>e.type==='shot'&&e.rail));
  }finally{a.dispose();}
});
test('runtime: invalid dt cannot corrupt the simulation and stale inputs release tactical actions',()=>{
  const a=arena();try{const p=player(a);const before=a.tick;for(const dt of [NaN,-1,0,Infinity])a.step(dt);assert.equal(a.tick,before);
    a.input(p.id,{detonate:true,shieldUse:true});ticks(a,30);assert.equal(p.detonateHeld,false);assert.equal(p.shieldUseHeld,false);assert.ok(Number.isFinite(p.y));
  }finally{a.dispose();}
});
test('operator: adult proportions and the complete animation mapping have finite geometry',()=>{
  for(let i=0;i<3;i++){
    const op=makeOperator(i,()=>undefined,()=>new T.Group(),WEAPONS),box=new T.Box3().setFromObject(op.model),height=box.max.y-box.min.y;
    assert.ok(height>1.75&&height<2.05,String(height));assert.ok(op.model.getObjectByName('Head'));assert.ok(op.model.getObjectByName('RightHand'));
    for(const clip of OPERATOR_CLIPS){const action=op.mixer.clipAction(clip);action.play();op.mixer.update(.1);action.stop();assert.ok(op.model.getObjectByName('Head').quaternion.toArray().every(Number.isFinite));}
    for(const m of op.model.userData.operatorMaterials)m.dispose();
  }
  assert.equal(new Set(OPERATOR_CLIPS.map(c=>c.name)).size,17);
});
test('weapon rigs: real removable magazines use separate transforms but share immutable geometry',()=>{
  const a=detailedWeapon(WEAPONS[0],()=>undefined),b=detailedWeapon(WEAPONS[0],()=>undefined);
  assert.ok(a.userData.mag.isMesh);assert.notEqual(a.userData.mag,b.userData.mag);assert.equal(a.userData.mag.geometry,b.userData.mag.geometry);
  a.userData.mag.position.y=-1;assert.notEqual(a.userData.mag.position.y,b.userData.mag.position.y);
  assert.ok(a.userData.bolt);assert.ok(detailedWeapon(WEAPONS[10],()=>undefined).userData.cylinder);
});
test('boss creatures: distinct silhouettes, multiple attack poses and no robot asset dependency',()=>{
  const shapes=[];
  for(const kind of ['might','fire','mind','chaos','void']){
    const c=makeCreature(kind);let meshes=0,verts=0;c.root.traverse(o=>{if(o.isMesh){meshes++;verts+=o.geometry.attributes.position.count;assert.ok(o.geometry.attributes.position.array.every(Number.isFinite));}});shapes.push(meshes+':'+verts);
    for(const anim of ['idle','walk','attack','cast','death']){c.animate({anim,windup:anim==='attack'?.3:0,animTime:.4,hp:anim==='death'?0:100},1,.1);c.root.updateMatrixWorld(true);assert.ok(c.body.matrixWorld.elements.every(Number.isFinite));}
    c.dispose();
  }
  assert.equal(new Set(shapes).size,5);
});
test('friends: corrupted saves and invalid codes cannot become invite recipients',()=>{
  assert.deepEqual(readFriends('not json'),[]);assert.equal(validFriendCode('javascript:alert(1)'),false);
  assert.ok(validFriendCode('0123456789ABCDEF01234567'));
  assert.deepEqual(readFriends('[{"code":"bad"}]'),[]);
});
