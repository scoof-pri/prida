import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { generateKeyPairSync, sign } from 'node:crypto';
import { WebSocketServer, WebSocket } from 'ws';
import { SocialService, codeOf } from '../social-server.mjs';
function message(ws,predicate,timeout=4000){return new Promise((resolve,reject)=>{const t=setTimeout(()=>{ws.off('message',receive);reject(Error('social timeout'));},timeout);const receive=raw=>{const m=JSON.parse(raw);if(predicate(m)){clearTimeout(t);ws.off('message',receive);resolve(m);}};ws.on('message',receive);});}
async function client(port,name){const key=generateKeyPairSync('ec',{namedCurve:'prime256v1'}),pub=key.publicKey.export({type:'spki',format:'der'}),ws=new WebSocket('ws://127.0.0.1:'+port+'/?social=1'),challenge=await message(ws,m=>m.type==='challenge');
  const ready=message(ws,m=>m.type==='identity');ws.send(JSON.stringify({type:'identify',name,pub:pub.toString('base64'),signature:sign('sha256',Buffer.from(challenge.value,'base64'),{key:key.privateKey,dsaEncoding:'ieee-p1363'}).toString('base64')}));const identity=await ready;assert.equal(identity.code,codeOf(pub));return {ws,code:identity.code};}

test('friends service: signed identity, mutual presence, invites and offline cleanup',async()=>{
  const wss=new WebSocketServer({port:0}),service=new SocialService();wss.on('connection',ws=>service.connect(ws));await once(wss,'listening');const port=wss.address().port;let a,b;
  try{a=await client(port,'ALPHA');b=await client(port,'BRAVO');
    let update=message(a.ws,m=>m.type==='presence');a.ws.send(JSON.stringify({type:'friends',codes:[b.code]}));assert.equal((await update).friends[0].online,false,'no unilateral tracking');
    update=message(a.ws,m=>m.type==='presence'&&m.friends[0]?.online);b.ws.send(JSON.stringify({type:'friends',codes:[a.code]}));assert.equal((await update).friends[0].name,'BRAVO');
    const invite=message(b.ws,m=>m.type==='invite');a.ws.send(JSON.stringify({type:'invite',to:b.code,room:'ABC123'}));assert.equal((await invite).room,'ABC123');
    update=message(a.ws,m=>m.type==='presence'&&m.friends[0]?.online===false);b.ws.close();await update;
  }finally{a?.ws.terminate();b?.ws.terminate();for(const ws of wss.clients)ws.terminate();await new Promise(r=>wss.close(r));}
});
test('friends service: a forged public-code identity is rejected',async()=>{
  const wss=new WebSocketServer({port:0}),service=new SocialService();wss.on('connection',ws=>service.connect(ws));await once(wss,'listening');const ws=new WebSocket('ws://127.0.0.1:'+wss.address().port);
  try{await message(ws,m=>m.type==='challenge');const key=generateKeyPairSync('ec',{namedCurve:'prime256v1'}),pub=key.publicKey.export({type:'spki',format:'der'});const closed=once(ws,'close');ws.send(JSON.stringify({type:'identify',pub:pub.toString('base64'),signature:Buffer.alloc(64).toString('base64')}));assert.equal((await closed)[0],1008);assert.equal(service.peers.size,0);
  }finally{ws.terminate();for(const s of wss.clients)s.terminate();await new Promise(r=>wss.close(r));}
});
