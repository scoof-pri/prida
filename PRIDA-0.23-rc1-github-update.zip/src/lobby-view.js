import * as T from 'three';
import { COSMETICS, appearance, pack } from './cosmetics.js';
import { CHARACTER_GUNS } from './assets.js';
// The lobby reuses the game's renderer/context, but has no world simulation or distant-city draw cost.
export class LobbyView {
  constructor(view,paint,pattern){
    this.view=view;this.paint=paint;this.pattern=pattern;this.time=0;this.turn=0;
    this.scene=new T.Scene();this.scene.background=new T.Color(0x122644);this.scene.environment=view.scene.environment;
    this.camera=new T.PerspectiveCamera(38,1,.05,35);
    this.scene.add(new T.HemisphereLight(0xd9efff,0x193548,2.2));
    for(const [x,y,z,color,intensity] of [[-2,5,4,0xf4ecdb,4],[4,3,-2,0x69bdf5,6]]){const l=new T.DirectionalLight(color,intensity);l.position.set(x,y,z);this.scene.add(l);}
    const plate=new T.Mesh(new T.CylinderGeometry(.92,1,.16,64),new T.MeshStandardMaterial({color:0x3e617b,roughness:.34,metalness:.55}));plate.position.set(1.35,-.1,0);this.scene.add(plate);
    const ring=new T.Mesh(new T.TorusGeometry(.91,.015,8,64),new T.MeshBasicMaterial({color:0x82d6fa}));ring.rotation.x=Math.PI/2;ring.position.set(1.35,-.012,0);this.scene.add(ring);this.stage=[plate,ring];
    const backdrop=new T.Mesh(new T.PlaneGeometry(30,12),new T.MeshStandardMaterial({color:0x234362,roughness:.8}));backdrop.position.set(0,2,-3);this.scene.add(backdrop);
    const floor=new T.Mesh(new T.PlaneGeometry(30,30),new T.MeshStandardMaterial({color:0x18334c,roughness:.52,metalness:.15}));floor.rotation.x=-Math.PI/2;floor.position.y=-.2;this.scene.add(floor);
    this.effect=new T.Group();this.scene.add(this.effect);this.orbGeo=new T.IcosahedronGeometry(.022,0);this.orbMat=new T.MeshBasicMaterial({color:0x9bd6eb});
    for(let i=0;i<16;i++)this.effect.add(new T.Mesh(this.orbGeo,this.orbMat));
  }
  update(config,dt){
    this.time+=dt;const look=appearance(config.look),weapon=config.weapon||0,key=pack(look)+'/'+weapon;
    if(key!==this.key){
      if(this.actor)this.view.removePerson(this.actor);
      this.actor=this.view.person({id:'lobby-preview',name:'PREVIEW',hp:100,shot:0,cosmetics:look},true);
      this.view.people.delete('lobby-preview');this.scene.add(this.actor.root);this.actor.hp.visible=this.actor.label.visible=false;
      const color=new T.Color(COSMETICS.find(c=>c.id===look.finish)?.color||'#9eb8c6');
      for(const g of this.actor.guns){this.paint(g,color);this.pattern(g,look.pattern,color);g.visible=g.name===CHARACTER_GUNS[weapon];}
      const skin=COSMETICS.find(c=>c.id===look.operator)?.skin;
      if(skin)this.actor.body.traverse(o=>{if(o.isMesh&&['Character_Main','Pants'].includes(o.material.name))o.material.color.set(skin);});
      this.key=key;
    }
    const v=this.actor,emote=COSMETICS.find(c=>c.id===look.emote),dance=emote?.dance;
    this.view.animate(v,config.emote?emote?.clip||'Wave':'Idle');v.mixer.update(dt);
    const focus=config.focus||innerWidth<700,x=focus?0:1.35;
    v.root.position.set(x,config.emote&&dance?.bob?Math.abs(Math.sin(this.time*(dance.speed||5)))*dance.bob:0,0);
    this.turn=config.turn||0;v.root.rotation.y=.18+this.turn+(config.emote&&dance?.spin?this.time*dance.spin:Math.sin(this.time*.23)*.13);
    for(const s of this.stage)s.position.x=x;
    const effect=COSMETICS.find(c=>c.id===look.effect);this.effect.visible=look.effect!=='noeffect';this.orbMat.color.set(effect?.color||'#9bd6eb');
    this.effect.children.forEach((o,i)=>{const a=i/16*Math.PI*2+this.time*.8;o.position.set(x+Math.cos(a)*.53,.18+((i/16+this.time*.16)%1)*1.65,Math.sin(a)*.53);});
    this.camera.aspect=this.view.renderer.domElement.clientWidth/Math.max(1,this.view.renderer.domElement.clientHeight);this.camera.position.set(0,1.34,focus?4.2:4.7);this.camera.lookAt(0,1.02,0);this.camera.updateProjectionMatrix();
    const r=this.view.renderer;r.setRenderTarget(null);r.autoClear=true;r.render(this.scene,this.camera);
  }
  dispose(){if(this.actor)this.view.removePerson(this.actor);this.scene.traverse(o=>{if(o.isMesh&&!o.isInstancedMesh&&!o.parent?.userData.procedural){/* Shared actor assets are owned by the asset cache. */}});}
}
