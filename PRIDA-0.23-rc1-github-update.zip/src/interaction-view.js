import * as T from 'three';
import { detailMaterial } from './materials.js';
import { syncInteractions } from './interactions.js';
export class InteractionViews {
  constructor(view,map){
    this.view=view;this.map=map;this.root=new T.Group();view.scene.add(this.root);
    const count=map.interactiveDoors.length+(map.lifts||[]).reduce((n,l)=>n+l.gates.length,0);
    this.geometry=new T.BoxGeometry(1,1,1);
    this.material=detailMaterial('oak',0xc0c5c3,{box:true,roughness:.65,key:'interactive-door'});
    this.doors=new T.InstancedMesh(this.geometry,this.material,Math.max(1,count));this.doors.frustumCulled=false;this.doors.castShadow=true;this.doors.receiveShadow=true;this.doors.instanceMatrix.setUsage(T.DynamicDrawUsage);this.root.add(this.doors);
    this.platforms=new Map();this.labels=new Map();
    const metal=detailMaterial('metal',0x87989d,{box:true,metalness:.55,roughness:.38,key:'elevator'});
    const box=(parent,x,y,z,w,h,d)=>{const m=new T.Mesh(this.geometry,metal);m.position.set(x,y,z);m.scale.set(w,h,d);m.castShadow=m.receiveShadow=true;parent.add(m);return m;};
    for(const l of map.lifts||[]){
      const g=new T.Group();g.position.set(l.x,0,l.z);this.root.add(g);const top=l.floors.at(-1)+2.7;
      for(const x of [-l.w/2,l.w/2])for(const z of [-l.d/2,l.d/2])box(g,x,top/2,z,.10,top,.10);
      for(const y of l.floors)box(g,0,y+2.55,0,l.w+.15,.12,l.d+.15);
      const platform=box(g,0,-.11,0,l.w,.22,l.d);this.platforms.set(l.id,{g,platform});
      // Opaque shaft backs avoid seeing a solid collision wall as empty space.
      box(g,l.w/2+.07,top/2,0,.08,top,l.d);
      for(const side of [-1,1])box(g,0,top/2,side*(l.d/2+.07),l.w,top,.08);
      for(let k=0;k<l.floors.length;k++){
        const sign=view.text('LIFT '+(k+1),.52,.17,'#dff5ef','#1a303e');sign.position.set(-l.w/2-.075,l.floors[k]+1.6,-l.d/2-.22);sign.rotation.y=-Math.PI/2;g.add(sign);
      }
    }
  }
  update(state,camera){
    syncInteractions(this.map,state);const mat=new T.Matrix4(),color=new T.Color(),far=this.view.viewDistance||250;let n=0;
    const draw=(o,tint)=>{if(Math.hypot(o.x-camera.position.x,o.z-camera.position.z)>far)return;mat.makeScale(o.w,o.h,o.d).setPosition(o.x,o.y,o.z);this.doors.setMatrixAt(n,mat);this.doors.setColorAt(n,color.set(tint));n++;};
    for(const d of this.map.interactiveDoors){
      if(d.broken)continue;draw(d.obstacle,d.number?0x748b89:0xa1977e);
      if(d.number&&Math.hypot(d.x-camera.position.x,d.z-camera.position.z)<15){
        let label=this.labels.get(d.id);if(!label){label=this.view.text(d.number,.32,.15,'#eef5eb','#233132');this.labels.set(d.id,label);this.root.add(label);}
        label.visible=true;label.position.set(d.obstacle.x+.069,d.y+1.7,d.obstacle.z);label.rotation.y=Math.PI/2;
      }else if(this.labels.has(d.id))this.labels.get(d.id).visible=false;
    }
    for(const l of this.map.lifts||[]){const v=this.platforms.get(l.id);v.g.visible=!l.broken&&Math.hypot(l.x-camera.position.x,l.z-camera.position.z)<far;if(!l.broken){v.platform.position.y=l.y-.11;for(const gate of l.gates)draw(gate,0x6d8995);}}
    this.doors.count=n;this.doors.instanceMatrix.needsUpdate=true;if(this.doors.instanceColor)this.doors.instanceColor.needsUpdate=true;
  }
  dispose(){this.root.removeFromParent();this.doors.dispose();this.geometry.dispose();this.root.traverse(o=>{if(o.userData.ownedTexture){o.material.map.dispose();o.material.dispose();o.geometry.dispose();}});this.labels.clear();}
}
