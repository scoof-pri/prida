// Anatomically proportioned procedural operators. Animation names stay compatible with saved cosmetics.
import * as T from 'three';
const sphere = new T.SphereGeometry(1, 14, 10), box = new T.BoxGeometry(1,1,1),
  capsule = new T.CapsuleGeometry(.5, 1, 4, 10);
function clip(name, duration, pose) {
  const times=[0,.25,.5,.75,1].map(t=>t*duration), tracks=[];
  for(const joint of ['LeftUpper','RightUpper','LeftLower','RightLower','LeftThigh','RightThigh','LeftCalf','RightCalf','Spine','Head']) {
    const values=[];
    for(let i=0;i<times.length;i++) {
      const e=pose(joint,i/4) || [0,0,0];
      const q=new T.Quaternion().setFromEuler(new T.Euler(...e)); values.push(...q.toArray());
    }
    tracks.push(new T.QuaternionKeyframeTrack(joint+'.quaternion',times,values));
  }
  return new T.AnimationClip(name,duration,tracks);
}
const arms=(n)=>n.endsWith('Upper')?[-.82,0,n.startsWith('Left')?-.16:.10]:n.endsWith('Lower')?[-1.05,0,0]:[0,0,0];
export const OPERATOR_CLIPS = [
  ...['Idle','Idle_Shoot','Walk','Walk_Shoot','Run','Run_Gun','Run_Shoot'].map(name=>clip(name,name.startsWith('Run')?.62:name.startsWith('Walk')?1:2,(n,t)=>{
    const gait=Math.sin(t*Math.PI*2), side=n.startsWith('Left')?1:-1, run=name.startsWith('Run'), walk=name.startsWith('Walk'),p=arms(n);
    if((walk||run)&&n.endsWith('Thigh'))return [gait*side*(run?.78:.38),0,0];
    if((walk||run)&&n.endsWith('Calf'))return [Math.max(0,-gait*side)*(run?1.1:.45),0,0];
    if(n==='Spine')return [run?.10:.018*Math.sin(t*Math.PI*2),walk||run?gait*.045:0,0];
    if(name==='Run'&&n.endsWith('Upper'))return [gait*-side*.55,0,side*.06];
    return p;
  })),
  clip('Jump',.65,(n,t)=>n.endsWith('Thigh')?[-.25,0,0]:n.endsWith('Calf')?[.65,0,0]:arms(n)),
  clip('Jump_Idle',1,n=>n.endsWith('Upper')?[-1.45,0,n.startsWith('Left')?-.32:.32]:n.endsWith('Thigh')?[.15,0,0]:n.endsWith('Calf')?[.32,0,0]:[0,0,0]),
  clip('Jump_Land',.35,(n,t)=>n==='Spine'?[Math.sin(Math.PI*t)*.3,0,0]:n.endsWith('Thigh')?[-Math.sin(Math.PI*t)*.45,0,0]:n.endsWith('Calf')?[Math.sin(Math.PI*t)*.7,0,0]:arms(n)),
  clip('Death',1.1,(n,t)=>n==='Spine'?[Math.min(1,t*2)*1.4,0,.12]:n.endsWith('Thigh')?[-t*.5,0,0]:arms(n)),
  clip('Duck',1,n=>n.endsWith('Thigh')?[-.65,0,0]:n.endsWith('Calf')?[1.05,0,0]:n==='Spine'?[.35,0,0]:arms(n)),
  clip('HitReact',.3,(n,t)=>n==='Spine'?[-Math.sin(t*Math.PI)*.2,0,0]:arms(n)),
  clip('Punch',.45,(n,t)=>n==='RightUpper'?[-.9-Math.sin(t*Math.PI)*.65,0,.1]:n==='RightLower'?[-1+Math.sin(t*Math.PI)*.95,0,0]:arms(n)),
  clip('Wave',1.4,(n,t)=>n==='RightUpper'?[0,0,-2.65]:n==='RightLower'?[0,0,Math.sin(t*Math.PI*4)*.45]:arms(n)),
  clip('Yes',1,n=>n==='Head'?[.18,0,0]:arms(n)),
  clip('No',1,(n,t)=>n==='Head'?[0,Math.sin(t*Math.PI*2)*.5,0]:arms(n)),
];
export function makeOperator(index, texture, gunFactory, weapons) {
  const root=new T.Group();root.name='Operator';root.userData.procedural=true;
  const own=new Set();
  const material=(name,color,metalness=0)=>{
    const m=new T.MeshStandardMaterial({color,roughness:metalness?.42:.84,metalness});m.name=name;m.userData.operatorOwned=true;own.add(m);return m;
  };
  const suit=material('Character_Main',[0x647462,0x958765,0x596e7f][index%3]),pants=material('Pants',0x3f4c4c),skin=material('Skin',0xb78461),
    rubber=material('Black',0x20282c),strap=material('DarkGrey',0x363e3c),steel=material('GearMetal',0x78888c,.55),glass=material('Visor',0x183b45,.6);
  for(const m of [suit,pants,strap]){m.map=texture('fabric');m.normalMap=texture('fabric_n');m.normalScale.set(.22,.22);m.roughnessMap=texture('fabric_arm');}
  const mesh=(p,g,m,x,y,z,sx,sy,sz)=>{const o=new T.Mesh(g,m);o.position.set(x,y,z);o.scale.set(sx,sy,sz);o.castShadow=o.receiveShadow=true;p.add(o);return o;};
  const joint=(p,name,x,y,z)=>{const g=new T.Group();g.name=name;g.position.set(x,y,z);p.add(g);return g;};
  mesh(root,sphere,pants,0,.94,0,.175,.15,.115);
  const spine=joint(root,'Spine',0,1.12,0);
  mesh(spine,sphere,suit,0,.15,0,.22,.30,.13);
  mesh(spine,box,strap,0,.17,.112,.34,.36,.09);
  for(const x of [-.105,0,.105]){
    mesh(spine,box,pants,x,.065,.188,.084,.17,.067);
    mesh(spine,box,steel,x,.10,.226,.047,.012,.008);
  }
  for(const x of [-.153,.153])mesh(spine,box,strap,x,.31,.095,.035,.27,.056);
  mesh(spine,box,steel,.14,.33,.157,.038,.068,.015);
  mesh(root,box,strap,0,.94,.10,.34,.055,.035);
  mesh(root,box,steel,0,.94,.123,.055,.035,.012);
  const head=joint(root,'Head',0,1.64,.005);
  mesh(head,capsule,skin,0,-.09,0,.105,.095,.10);
  mesh(head,sphere,skin,0,.06,0,.097,.123,.091);
  mesh(head,sphere,skin,0,.035,.076,.026,.021,.035);
  for(const x of [-.033,.033])mesh(head,box,rubber,x,.079,.085,.022,.008,.009);
  if(index%3!==2){
    const helmet=mesh(head,sphere,index%3===1?suit:strap,0,.114,-.004,.118,.09,.109);
    for(const x of [-.11,.11])mesh(head,box,rubber,x,.075,0,.021,.063,.061);
    if(index%3===1){mesh(head,sphere,glass,0,.052,.059,.102,.083,.075);for(const x of [-.079,.079])mesh(head,capsule,rubber,x,-.017,.09,.047,.06,.047);}
  }else{mesh(head,sphere,pants,0,.145,-.013,.105,.033,.101);mesh(head,box,pants,0,.125,.08,.18,.015,.10);}
  const hands={};
  for(const [side,s] of [['Left',-1],['Right',1]]){
    const upper=joint(root,side+'Upper',s*.23,1.46,0);
    mesh(upper,capsule,suit,0,-.145,0,.132,.15,.129);
    const lower=joint(upper,side+'Lower',0,-.29,0);mesh(lower,capsule,suit,0,-.131,0,.109,.133,.104);
    mesh(lower,sphere,strap,0,-.018,-.018,.068,.058,.075);
    const hand=joint(lower,side+'Hand',0,-.277,0);mesh(hand,sphere,rubber,0,-.037,.012,.048,.074,.036);hands[side]=hand;
    const thigh=joint(root,side+'Thigh',s*.105,.92,0);mesh(thigh,capsule,pants,0,-.20,0,.175,.218,.174);
    mesh(thigh,box,strap,s*.055,-.21,.005,.075,.18,.105);
    const calf=joint(thigh,side+'Calf',0,-.415,0);mesh(calf,capsule,pants,0,-.186,0,.123,.205,.126);
    mesh(calf,sphere,strap,0,-.017,.073,.084,.104,.042);
    mesh(calf,box,rubber,0,-.42,.046,.141,.15,.25);
    mesh(calf,box,rubber,0,-.492,.046,.151,.021,.267);
  }
  const attached=new Set();
  weapons.forEach((w,i)=>{
    const name=w.char.startsWith('mount:')?'Mount_'+w.model:w.char;if(attached.has(name))return;attached.add(name);
    const g=gunFactory(i);g.name=name;g.rotation.y=Math.PI;g.position.set(0,-.045,.14);g.visible=false;
    hands.Right.add(g);
  });
  root.userData.operatorMaterials=own;
  return {model:root,mixer:new T.AnimationMixer(root),clips:OPERATOR_CLIPS};
}
