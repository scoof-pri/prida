// Authoritative thrown equipment. Cosmetic meshes never decide damage, ammo, ownership or timing.
import { castMap } from './raycast.js';
import { groundHeight } from './terrain.js';
export const MAX_CHARGES = 3;
const normalise = v => { const n=Math.hypot(v.x,v.y,v.z)||1; return {x:v.x/n,y:v.y/n,z:v.z/n}; };
export function stepOrdnance(a, r, w, dt) {
  const owner=a.players.find(p=>p.id===r.owner);
  r.age=(r.age||0)+dt; r.life-=dt;
  if(w.remote && (!owner || owner.hp<=0 || r.life<=0)) return true;
  if(r.life<=0) { a.blast(r.x,r.y,r.z,w.radius,w.damage,owner,r.kind); return true; }
  if(r.stuck) {
    const attached=r.anchor && a.map.obstacles.some(o=>
      r.anchor.panel!==undefined ? o.panel===r.anchor.panel : r.anchor.prop!==undefined ? o.prop===r.anchor.prop : r.anchor.decor!==undefined && o.decor===r.anchor.decor);
    if(!r.anchor || attached) return false;
    r.stuck=false; r.vy=-.2; delete r.anchor;
  }
  // Substeps bound arc curvature; segment rays prevent tunnelling at low server tick rates.
  const n=Math.max(1,Math.ceil(dt/.025)), h=dt/n;
  for(let i=0;i<n;i++) {
    r.vy-=w.gravity*h;
    const speed=Math.hypot(r.vx,r.vy,r.vz), dir=normalise({x:r.vx,y:r.vy,z:r.vz}), len=speed*h;
    r.dx=dir.x;r.dy=dir.y;r.dz=dir.z;
    const cast=castMap(r,dir,len+.035,a.map);
    const distance=cast.impact?Math.max(0,Math.min(len,cast.distance-.035)):len;
    r.x+=dir.x*distance; r.y+=dir.y*distance; r.z+=dir.z*distance;
    if(cast.impact) {
      const hit=cast.impact, normal=normalise(hit);
      r.x+=normal.x*.045;r.y+=normal.y*.045;r.z+=normal.z*.045;
      if(w.remote) {
        r.stuck=true;r.normal=normal;r.vx=r.vy=r.vz=0;
        const o=hit.obstacle;
        if(o && (o.panel!==undefined||o.prop!==undefined||o.decor!==undefined))r.anchor={panel:o.panel,prop:o.prop,decor:o.decor};
        // Never put an obstacle object (with cached grids/cells) in a network event.
        a.events.push({type:'impact',x:r.x,y:r.y,z:r.z,weapon:r.weapon,hit:false,impact:{kind:hit.kind,...normal}});
        break;
      }
      const dot=r.vx*normal.x+r.vy*normal.y+r.vz*normal.z, bounce=w.bounce??.42;
      r.vx=(r.vx-(1+bounce)*dot*normal.x)*.78;
      r.vy=(r.vy-(1+bounce)*dot*normal.y)*.78;
      r.vz=(r.vz-(1+bounce)*dot*normal.z)*.78;
      if(normal.y>.7 && Math.hypot(r.vx,r.vy,r.vz)<.7){r.vx=r.vy=r.vz=0;}
    }
    r.y=Math.max(r.y,groundHeight(r.x,r.z,a.map)+.05);
    if(Math.abs(r.x)>a.map.limit.x-1||Math.abs(r.z)>a.map.limit.z-1){r.vx*=-.5;r.vz*=-.5;r.x=Math.max(-a.map.limit.x+1,Math.min(a.map.limit.x-1,r.x));r.z=Math.max(-a.map.limit.z+1,Math.min(a.map.limit.z-1,r.z));}
  }
  return false;
}
