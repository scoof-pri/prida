import * as T from 'three';
import { detailMaterial } from './materials.js';
const rock=new T.IcosahedronGeometry(1,1), smooth=new T.SphereGeometry(1,16,12), cone=new T.ConeGeometry(1,1,9), tube=new T.CylinderGeometry(1,1,1,10);
const COLORS={might:0xa39779,fire:0x38332d,mind:0x635480,chaos:0x3c5b4b,void:0x262935};
const ENERGY={might:0xe1b96a,fire:0xff651c,mind:0xc3a4ff,chaos:0x60e0b6,void:0x9285ff};
// Five silhouettes, not variants of the robot rig. Joints are animated from authoritative boss timings.
export function makeCreature(kind){
  const root=new T.Group(),body=new T.Group();root.add(body);
  const stone=detailMaterial('rock',COLORS[kind],{box:true,roughness:.94,key:'creature-'+kind}),
    cloth=detailMaterial('fabric',COLORS[kind],{box:true,roughness:.87,key:'cloak-'+kind}),
    glow=new T.MeshStandardMaterial({color:ENERGY[kind],emissive:ENERGY[kind],emissiveIntensity:1.8,roughness:.45}),
    dark=new T.MeshStandardMaterial({color:0x121b20,roughness:.92});
  const materials=[stone,cloth,glow,dark];
  const joint=(p,x,y,z)=>{const j=new T.Group();j.position.set(x,y,z);p.add(j);return j;};
  const part=(p,g,m,x,y,z,sx,sy,sz)=>{const v=new T.Mesh(g,m);v.position.set(x,y,z);v.scale.set(sx,sy,sz);v.castShadow=v.receiveShadow=true;p.add(v);return v;};
  const ethereal=['mind','void'].includes(kind), arms=[],legs=[],orbit=[];
  if(ethereal){
    part(body,cone,cloth,0,1.38,0,.75,2.65,.55); // layered robe with a closed silhouette
    for(let i=0;i<10;i++){const a=i*Math.PI/5;const p=part(body,cone,cloth,Math.cos(a)*.36,.80,Math.sin(a)*.31,.20,1.62,.12);p.rotation.z=Math.sin(a)*.17;}
    part(body,smooth,cloth,0,2.82,0,.51,.68,.39);
    part(body,smooth,dark,0,2.88,.315,.36,.43,.12);
    for(const side of [-1,1])part(body,smooth,glow,side*.13,2.92,.435,.062,.029,.02);
    if(kind==='mind'){
      const halo=new T.Mesh(new T.TorusGeometry(.63,.04,8,36),glow);halo.position.set(0,3.20,0);halo.rotation.x=Math.PI/2;body.add(halo);orbit.push(halo);
      for(let i=0;i<5;i++){const o=part(root,smooth,glow,0,0,0,.11,.11,.11);o.userData.orbit=i;orbit.push(o);}
    }else{
      for(const side of [-1,1])for(let i=0;i<3;i++){const h=part(body,cone,stone,side*(.34+i*.16),3.31+i*.1,-.14,.12,.66-i*.1,.12);h.rotation.z=-side*.45;}
      const halo=new T.Mesh(new T.TorusGeometry(1.13,.048,8,48),glow);halo.position.set(0,2.35,-.38);body.add(halo);orbit.push(halo);
    }
  }else{
    part(body,rock,stone,0,1.42,0,.60,.54,.42);
    part(body,rock,stone,0,2.17,0,kind==='might'?.99:.73,.80,.49);
    part(body,rock,stone,0,3.10,.02,.38,.47,.32);
    part(body,rock,stone,0,2.89,.23,.31,.16,.22);
    for(const side of [-1,1])part(body,smooth,glow,side*.14,3.14,.313,.082,.036,.025);
    for(const side of [-1,1]){
      const l=joint(body,side*.36,1.45,0);legs.push(l);part(l,rock,stone,0,-.45,0,.32,.57,.31);part(l,rock,stone,0,-1.0,.10,.32,.41,.38);
    }
    if(kind==='fire'){
      for(let i=0;i<18;i++){
        const a=i*2.399, y=1.5+(i%6)*.23;
        const c=part(body,rock,glow,Math.cos(a)*.59,y,Math.sin(a)*.39,.055,.19,.06);c.rotation.z=a;
      }
      for(const side of [-1,1])for(let i=0;i<3;i++){const p=part(body,cone,stone,side*(.56+i*.12),2.78+i*.09,0,.18,.69,.17);p.rotation.z=-side*.4;}
    }
    if(kind==='might'){
      for(const side of [-1,1]){part(body,rock,stone,side*.87,2.64,0,.46,.39,.47);part(body,cone,stone,side*.91,2.99,0,.17,.48,.17);}
    }
    if(kind==='chaos'){
      for(let i=0;i<9;i++){const o=part(root,cone,i%3===0?glow:stone,0,0,0,.13,.46,.12);o.userData.orbit=i;orbit.push(o);}
      for(const side of [-1,1]){const horn=part(body,cone,stone,side*.29,3.43,0,.13,.7,.13);horn.rotation.z=-side*.38;}
    }
  }
  const armCount=kind==='chaos'?4:2;
  for(let i=0;i<armCount;i++){
    const side=i%2?1:-1,lower=i>1,a=joint(body,side*(ethereal?.48:.77),lower?2:2.7,0);a.userData.side=side;a.userData.lower=lower;
    part(a,ethereal?tube:rock,ethereal?cloth:stone,side*.10,-.43,0,ethereal?.17:.30,.56,ethereal?.16:.30);
    const fore=joint(a,side*.10,-.78,.08);part(fore,rock,stone,0,-.34,0,ethereal?.13:.24,.44,ethereal?.12:.26);
    part(fore,rock,ethereal?dark:stone,0,-.66,.07,kind==='might'?.40:.19,.25,.24);
    arms.push({a,fore,side,lower});
  }
  const telegraph=new T.Mesh(new T.RingGeometry(1.1,1.20,48),new T.MeshBasicMaterial({color:ENERGY[kind],transparent:true,opacity:.6,depthWrite:false,side:T.DoubleSide}));
  telegraph.rotation.x=-Math.PI/2;telegraph.position.y=.045;root.add(telegraph);
  let death=0;
  return {root,body,materials,animate(b,time,dt){
    const wind=Math.max(0,b.windup||0),t=b.animTime||0,walking=b.anim==='walk',casting=b.anim==='cast',attack=b.anim==='attack';
    death=b.hp<=0?Math.min(1,death+dt):0;body.rotation.x=death*1.5;body.position.y=ethereal?.12+Math.sin(time*1.3)*.09:Math.abs(Math.sin(time*4))* (walking?.055:0);
    if(death)body.position.y=-death*.5;
    for(let i=0;i<legs.length;i++)legs[i].rotation.x=walking?Math.sin(time*4+i*Math.PI)*.48:0;
    for(const {a,fore,side,lower} of arms){
      a.rotation.set(walking?Math.sin(time*4+side)*.28:0,0,side*(lower?.6:.16));fore.rotation.x=-.18;
      if(attack){a.rotation.x=wind>0?-2.1*(1-wind/.55):.75*Math.exp(-t*2);fore.rotation.x=wind>0?-.6:-.08;}
      if(casting){a.rotation.x=kind==='fire'?-1.35:kind==='might'?-2.5:-.92;a.rotation.z=side*(kind==='chaos'?1.1:.65);fore.rotation.x=-.8;}
      if(b.anim==='confused')a.rotation.z+=Math.sin(time*7)*.12;
    }
    for(const o of orbit){if(o.userData.orbit!==undefined){const a=time*(kind==='chaos'?1.2:.5)+o.userData.orbit*2.399;o.position.set(Math.cos(a)*(kind==='chaos'?1.35:1),2.4+Math.sin(a*1.4)*.8,Math.sin(a)*(kind==='chaos'?1.35:1));o.rotation.set(a,a*.6,a*.2);}else o.rotation.z=time*.14;}
    telegraph.visible=b.hp>0&&(wind>0||casting);telegraph.scale.setScalar(kind==='might'?2.8:kind==='fire'?2:1.4);telegraph.material.opacity=.25+.4*Math.max(0,Math.sin(time*14));
  },dispose(){for(const m of [glow,dark])m.dispose();telegraph.geometry.dispose();telegraph.material.dispose();root.removeFromParent();}};
}
