// Shared interactive geometry; all movement and collision is authoritative in Arena.
function removeObstacle(map,o) { const i=map.obstacles.indexOf(o); if(i<0)return; map.obstacles.splice(i,1); map.obstacles.grid?.remove(o);map.obstacles.lowGrid?.remove(o); }
export function floorHeight(k) { return k === 0 ? 0 : 3.84 + (k - 1) * 3.6; }
export function prepareInteractions(map) {
  map.interactiveDoors = [...map.doors.map((d, i) => ({ ...d, id: 'entry'+i, y: 0, axis: 'x', initial: 1 })), ...(map.flatDoors || [])].map(d => {
    const axis = d.axis || 'x', open = d.initial || 0, h = 2.5, shift = d.w * open;
    const obstacle = { x:d.x+(axis==='x'?shift:0), y:(d.y||0)+h/2, z:d.z+(axis==='z'?shift:0), w:axis==='x'?d.w:.12, h, d:axis==='z'?d.w:.12, part:'door', hp:90, building:d.building, storey:d.storey||0, interactive:d.id, color:0x84705a };
    map.obstacles.push(obstacle); return { ...d, axis, initial:open, open, target:open, obstacle };
  });
  for(const l of map.lifts || []) {
    l.y=0;l.floor=0;l.target=0;l.door=1;l.phase='idle';l.wait=0;
    l.platform={x:l.x,y:-.11,z:l.z,w:l.w,h:.22,d:l.d,part:'lift-platform',building:l.building,interactive:l.id};
    map.obstacles.push(l.platform);
    const top=l.floors.at(-1)+2.7;
    // Shaft sides are solid. The west face is served by individual floor gates.
    for(const side of [-1,1])map.obstacles.push({x:l.x,y:top/2,z:l.z+side*(l.d/2+.08),w:l.w+.2,h:top,d:.12,part:'lift-wall',building:l.building});
    map.obstacles.push({x:l.x+l.w/2+.08,y:top/2,z:l.z,w:.12,h:top,d:l.d+.2,part:'lift-wall',building:l.building});
    l.gates=l.floors.map((y,k)=>{
      const o={x:l.x-l.w/2-.04,y:y+1.25,z:l.z+(k===0?l.d:0),w:.12,h:2.5,d:l.d,part:'lift-gate',building:l.building,storey:k,interactive:l.id};
      map.obstacles.push(o);return o;
    });
  }
}
const intact = (map, d) => { const b=map.buildings[d.building];return b&&!b.collapsed&&!(b.fallenFrom!==undefined && (d.storey||0)>=b.fallenFrom); };
export function interactionNear(map, p) {
  let nearest=null, best=2.7;
  for(const d of map.interactiveDoors || []) {
    if(d.broken||!intact(map,d)||Math.abs((d.y||0)-p.y)>1.6)continue;
    const dist=Math.hypot(p.x-d.x,p.z-d.z);
    if(dist<best){best=dist;nearest={type:'door',id:d.id,label:(d.open>.5?'CLOSE':'OPEN')+' DOOR'+(d.number?' '+d.number:''),door:d};}
  }
  for(const l of map.lifts||[]) {
    if(l.broken||!intact(map,l))continue;
    const inside=Math.abs(p.x-l.x)<l.w/2+.2&&Math.abs(p.z-l.z)<l.d/2+.2&&Math.abs(p.y-l.y)<.5;
    const k=l.floors.findIndex(y=>Math.abs(y-p.y)<1.2);
    const dist=Math.hypot(p.x-(l.x-l.w/2-.6),p.z-l.z);
    if(inside || k>=0&&dist<best){best=inside?0:dist;nearest={type:'lift',id:l.id,floor:inside?(l.floor+1)%l.floors.length:k,label:inside?'LIFT · NEXT FLOOR':'CALL LIFT · FLOOR '+(k+1),lift:l};}
  }
  return nearest;
}
function moveGeometry(map,o,x,y,z) {
  if(Math.abs(o.x-x)<.0001&&Math.abs(o.y-y)<.0001&&Math.abs(o.z-z)<.0001)return;
  map.obstacles.grid?.remove(o);map.obstacles.lowGrid?.remove(o);
  Object.assign(o,{x,y,z});map.obstacles.grid?.add(o);
  if(y-o.h/2<1.8)map.obstacles.lowGrid?.add(o);
}
export class Interactions {
  constructor(arena){this.a=arena;this.doors=arena.map.interactiveDoors;this.lifts=arena.map.lifts||[];}
  use(p){
    if(!p||p.hp<=0||p.inBus||p.frozen>0)return false;
    const q=interactionNear(this.a.map,p);if(!q)return false;
    if(q.type==='door')q.door.target=q.door.target>.5?0:1;
    else if(q.lift.phase==='idle'){q.lift.target=q.floor;q.lift.phase='closing';q.lift.wait=.5;}
    this.a.events.push({type:'interact',id:p.id,kind:q.type});return true;
  }
  move(o,x,y,z){
    moveGeometry(this.a.map,o,x,y,z);
    const collider=this.a.colliders.get(o);
    if(collider&&!Array.isArray(collider))collider.setTranslation({x,y,z});
    this.a.physicsDirty=true;
  }
  step(dt){
    const a=this.a;
    for(const d of this.doors){
      if(d.broken)continue;
      if(!intact(a.map,d)||!a.colliders.has(d.obstacle)){d.broken=true;if(a.colliders.has(d.obstacle))a.removeObs(d.obstacle);continue;}
      if(d.target<.5&&a.players.some(p=>p.hp>0&&Math.abs(p.y-(d.y||0))<1.8&&Math.abs(p.x-d.x)<(d.axis==='x'?d.w/2+.5:.7)&&Math.abs(p.z-d.z)<(d.axis==='z'?d.w/2+.5:.7)))d.target=1;
      // Bots request nearby exterior doors instead of getting permanently stuck on their path.
      if(d.storey===0&&a.players.some(p=>p.bot&&p.hp>0&&Math.hypot(p.x-d.x,p.z-d.z)<1.7))d.target=1;
      const next=d.open+Math.sign(d.target-d.open)*Math.min(Math.abs(d.target-d.open),dt*2.8);
      if(next===d.open)continue;d.open=next;
      this.move(d.obstacle,d.x+(d.axis==='x'?d.w*d.open:0),(d.y||0)+1.25,d.z+(d.axis==='z'?d.w*d.open:0));
      a.navDirty=true;
    }
    for(const l of this.lifts){
      if(l.broken)continue;
      if(!intact(a.map,l)){l.broken=true;for(const o of [l.platform,...l.gates,...a.map.obstacles.filter(o=>o.building===l.building&&o.part==='lift-wall')])if(a.colliders.has(o))a.removeObs(o);continue;}
      if(l.phase==='closing'){
        // Safety edge: reopen rather than crushing a player in a landing doorway.
        const edge=a.players.some(p=>p.hp>0&&Math.abs(p.y-l.y)<1&&Math.abs(p.x-(l.x-l.w/2))<.4&&Math.abs(p.z-l.z)<l.d/2+.25);
        if(edge){l.wait=.5;l.door=Math.min(1,l.door+dt*3);}else{l.door=Math.max(0,l.door-dt*3);if(l.door===0){l.wait-=dt;if(l.wait<=0)l.phase='moving';}}
      } else if(l.phase==='moving'){
        const target=l.floors[l.target],dy=Math.sign(target-l.y)*Math.min(Math.abs(target-l.y),dt*2.1),old=l.y;
        const riders=a.players.filter(p=>p.hp>0&&!p.inBus&&Math.abs(p.x-l.x)<l.w/2-.1&&Math.abs(p.z-l.z)<l.d/2-.1&&Math.abs(p.y-old)<.24);
        l.y+=dy;this.move(l.platform,l.x,l.y-.11,l.z);
        for(const p of riders){a.place(p,p.x,p.z,p.y+dy);p.vy=0;p.grounded=true;}
        if(Math.abs(target-l.y)<.001){l.floor=l.target;l.phase='opening';}
      } else if(l.phase==='opening'){l.door=Math.min(1,l.door+dt*3);if(l.door===1)l.phase='idle';}
      for(let k=0;k<l.gates.length;k++){
        const gate=l.gates[k],open=k===l.floor&&Math.abs(l.y-l.floors[k])<.03?l.door:0,z=l.z+open*l.d;
        if(Math.abs(gate.z-z)>.001)this.move(gate,gate.x,gate.y,z);
      }
    }
  }
  snapshot(){return {doors:this.doors.filter(d=>d.broken||Math.abs(d.open-d.initial)>.001||d.target!==d.initial).map(d=>({id:d.id,open:+d.open.toFixed(3),broken:!!d.broken})),lifts:this.lifts.map(l=>({id:l.id,y:+l.y.toFixed(3),floor:l.floor,target:l.target,door:+l.door.toFixed(3),phase:l.phase,broken:!!l.broken}))};}
}
// Client-side geometry mirror for sight lines and movement prediction. Never feeds back into the server.
export function syncInteractions(map,state){
  const ds=new Map((state.doors||[]).map(d=>[d.id,d]));
  for(const d of map.interactiveDoors||[]){const v=ds.get(d.id);d.open=v?.open??d.initial;d.broken=!!v?.broken;
    if(d.broken){removeObstacle(map,d.obstacle);continue;}
    moveGeometry(map,d.obstacle,d.x+(d.axis==='x'?d.w*d.open:0),(d.y||0)+1.25,d.z+(d.axis==='z'?d.w*d.open:0));
  }
  const ls=new Map((state.lifts||[]).map(l=>[l.id,l]));
  for(const l of map.lifts||[]){const v=ls.get(l.id);if(v)Object.assign(l,v);if(l.broken){for(const o of [l.platform,...l.gates,...map.obstacles.filter(o=>o.building===l.building&&o.part==='lift-wall')])removeObstacle(map,o);continue;}
    moveGeometry(map,l.platform,l.x,l.y-.11,l.z);
    for(let k=0;k<l.gates.length;k++){const g=l.gates[k];moveGeometry(map,g,g.x,g.y,l.z+(k===l.floor?l.door*l.d:0));}
  }
}
