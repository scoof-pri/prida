// Original PRIDA equipment meshes. All dimensions are visual game units, not manufacturing specifications.
import * as T from 'three';
export function gadgetModel(kind) {
  const root = new T.Group();
  const metal = new T.MeshStandardMaterial({ color: 0x343d43, metalness: .72, roughness: .37 });
  const fabric = new T.MeshStandardMaterial({ color: 0x596348, roughness: .91 });
  const accent = new T.MeshStandardMaterial({ color: 0xc09348, metalness: .45, roughness: .42 });
  const glass = new T.MeshStandardMaterial({ color: 0x153449, emissive: 0x38a7d3, emissiveIntensity: .4, roughness: .24 });
  const mesh = (g, m, x=0,y=0,z=0) => { const o = new T.Mesh(g,m); o.position.set(x,y,z); root.add(o); return o; };
  const box = (w,h,d,m,x=0,y=0,z=0) => mesh(new T.BoxGeometry(w,h,d),m,x,y,z);
  if (kind === 'handgrenade') {
    const body=mesh(new T.SphereGeometry(.09,16,12),fabric); body.scale.set(1,1.28,1);
    for(let i=0;i<4;i++){ const ring=mesh(new T.TorusGeometry(.087, .006,5,16),metal,0,-.068+i*.044,0);ring.rotation.x=Math.PI/2; }
    mesh(new T.CylinderGeometry(.029,.04,.047,10),metal,0,.123,0);
    box(.026,.019,.15,accent,0,.147,.035);
    const ring=mesh(new T.TorusGeometry(.035,.006,6,16),metal,.037,.145,-.019); ring.rotation.y=Math.PI/2;
  } else if(kind==='c4') {
    box(.26,.115,.19,fabric);
    for(const z of [-.068,.068])box(.272,.128,.023,metal,0,0,z);
    box(.092,.038,.103,metal,.024,.073,0);
    box(.064,.006,.045,glass,.024,.095,-.013);
    for(const x of [-.05,-.017,.017])mesh(new T.CylinderGeometry(.01,.01,.006,8),accent,x,.079,.06);
    box(.065,.033,.11,metal,-.10,.082,0);
  } else {
    // Twin induction rails, shroud, optic, grip and visible replaceable power cell.
    box(.76,.13,.14,metal,0,.02,0);
    for(const z of [-.098,.098])box(.68,.045,.032,glass,.04,.035,z);
    box(.19,.19,.19,fabric,-.33,-.01,0);
    box(.1,.17,.075,metal,-.17,-.10,0);
    const cell=box(.09,.17,.10,accent,.02,-.09,0);cell.name='Magazine';
    box(.14,.043,.076,metal,-.10,.13,0);
    mesh(new T.CylinderGeometry(.035,.035,.21,10),glass,-.10,.18,0).rotation.z=Math.PI/2;
  }
  root.traverse(o=>{if(o.isMesh)o.castShadow=o.receiveShadow=true;});
  return root;
}
