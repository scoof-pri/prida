// Opaque, closed-volume loot chests. Four instanced batches for the entire map: wood/metal body and lid.
// The old imported crate was a thin two-sided shell; forcing FrontSide made its interior disappear.
import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { texture } from './assets.js';
import { RARITIES } from './catalog.js';

export function chestGeometry(lid = false, trim = false) {
  const parts = [];
  const box = (x, y, z, w, h, d) => parts.push(new T.BoxGeometry(w, h, d).translate(x, y, z));
  if (lid) {
    // Lid-local origin is the rear hinge, not its centre.
    if (!trim) box(0, .04, .38, 1.22, .12, .82);
    else {
      for (const x of [-.46, .46]) box(x, .11, .38, .075, .035, .84);
      box(0, .02, .79, .14, .18, .065);
      for (const x of [-.4, .4]) box(x, 0, 0, .13, .085, .12);
    }
  } else if (!trim) {
    box(0, .10, 0, 1.22, .16, .82);
    for (const side of [-1, 1]) {
      box(side * .56, .41, 0, .10, .54, .82);
      box(0, .41, side * .36, 1.06, .54, .10);
    }
  } else {
    for (const side of [-1, 1]) {
      for (const x of [-.46, .46]) box(x, .40, side * .416, .075, .63, .025);
      box(side * .618, .40, 0, .025, .13, .27);
    }
    box(0, .55, .43, .17, .16, .04);
    for (const y of [.08, .66]) for (const side of [-1, 1]) box(0, y, side * .42, 1.25, .04, .035);
  }
  const g = mergeGeometries(parts);
  for (const part of parts) part.dispose();
  g.computeBoundingBox(); g.computeBoundingSphere();
  return g;
}
export class ChestField {
  constructor(scene) {
    this.scene = scene; this.slots = new Map(); this.capacity = 0;
    this.geometries = [chestGeometry(), chestGeometry(false, true), chestGeometry(true), chestGeometry(true, true)];
    this.wood = new T.MeshStandardMaterial({ color: 0x9e7344, map: texture('oak') || null, normalMap: texture('oak_n') || null, roughness: .86, transparent: false, opacity: 1, depthWrite: true, side: T.FrontSide });
    this.metal = new T.MeshStandardMaterial({ color: 0xffffff, roughness: .35, metalness: .65, transparent: false, opacity: 1, depthWrite: true });
    this.grow(128);
  }
  grow(capacity) {
    for (const m of this.meshes || []) { m.removeFromParent(); m.dispose(); }
    this.meshes = this.geometries.map((g, i) => {
      const m = new T.InstancedMesh(g, i % 2 ? this.metal : this.wood, capacity);
      m.castShadow = m.receiveShadow = true; m.frustumCulled = false;
      m.instanceMatrix.setUsage(T.DynamicDrawUsage); m.count = 0; this.scene.add(m); return m;
    });
    this.body = this.meshes[0]; this.lid = this.meshes[2]; this.capacity = capacity;
  }
  update(chests, dt, hidden = () => false) {
    if (chests.length > this.capacity) this.grow(Math.max(chests.length, this.capacity * 2));
    const root = new T.Matrix4(), hinge = new T.Matrix4(), lidM = new T.Matrix4(),
      rot = new T.Quaternion(), scale = new T.Vector3(1, 1, 1), pos = new T.Vector3(), tint = new T.Color(), seen = new Set();
    let n = 0;
    for (const c of chests) {
      seen.add(c.id);
      let st = this.slots.get(c.id);
      if (!st) this.slots.set(c.id, st = { open: c.opened ? 1 : 0 });
      st.open = T.MathUtils.damp(st.open, c.opened ? 1 : 0, 9, Math.min(.1, Math.max(0, dt)));
      if (hidden(c)) continue;
      rot.setFromAxisAngle(new T.Vector3(0, 1, 0), c.angle || 0);
      root.compose(pos.set(c.x, (c.y ?? 0) + .03, c.z), rot, scale);
      hinge.makeRotationX(-st.open * 1.72).setPosition(0, .69, -.39);
      lidM.multiplyMatrices(root, hinge);
      tint.set(RARITIES[c.loot?.r ?? 0]?.color || '#d9bf7f');
      for (let k = 0; k < 4; k++) {
        this.meshes[k].setMatrixAt(n, k < 2 ? root : lidM);
        if (k % 2) this.meshes[k].setColorAt(n, tint);
      }
      n++;
    }
    for (const id of this.slots.keys()) if (!seen.has(id)) this.slots.delete(id);
    for (const m of this.meshes) { m.count = n; m.instanceMatrix.needsUpdate = true; if (m.instanceColor) m.instanceColor.needsUpdate = true; }
  }
  dispose() {
    for (const m of this.meshes) { m.removeFromParent(); m.dispose(); }
    for (const g of this.geometries) g.dispose();
    this.wood.dispose(); this.metal.dispose(); this.slots.clear();
  }
}
