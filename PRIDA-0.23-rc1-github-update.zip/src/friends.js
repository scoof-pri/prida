import { validEndpoint, roomCode } from './party.js';
const KEY='prida-social-identity-v1',LIST='prida-friends-v1';
const to64=buffer=>btoa(String.fromCharCode(...new Uint8Array(buffer))),from64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const cleanCode=s=>String(s||'').replace(/[\s-]/g,'').toUpperCase();
export const validFriendCode=s=>/^[A-F0-9]{24}$/.test(cleanCode(s));
export function readFriends(text){try{return JSON.parse(text).filter(x=>x&&validFriendCode(x.code)).slice(0,32).map(x=>({code:cleanCode(x.code),name:String(x.name||'FRIEND').slice(0,16)}));}catch{return [];}}
export class Friends {
  constructor({endpoint,name,group,join,changed}){this.endpoint=endpoint;this.name=name;this.group=group;this.join=join;this.changed=changed;this.list=[];this.status='OFFLINE';this.presence=new Map();try{this.list=readFriends(localStorage.getItem(LIST));}catch{};this.invitation=null;}
  async identity(){
    if(!crypto.subtle)throw Error('Device identity needs HTTPS or localhost.');
    let saved;try{saved=JSON.parse(localStorage.getItem(KEY));}catch{}
    if(saved){try{return {privateKey:await crypto.subtle.importKey('jwk',saved.privateKey,{name:'ECDSA',namedCurve:'P-256'},false,['sign']),pub:saved.pub};}catch{throw Error('Stored identity is invalid. Clear PRIDA device data to create a new one.');}}
    const keys=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
    const privateKey=await crypto.subtle.exportKey('jwk',keys.privateKey),pub=to64(await crypto.subtle.exportKey('spki',keys.publicKey));
    try{localStorage.setItem(KEY,JSON.stringify({privateKey,pub}));}catch{throw Error('Device storage is unavailable. Friends need local storage.');}
    return {privateKey:keys.privateKey,pub};
  }
  async connect(){
    if(this.ws&&this.ws.readyState<2)return;
    try{
      this.keys=await this.identity();const endpoint=this.endpoint();if(!endpoint)throw Error('Configure a PRIDA server in ONLINE first.');
      const url=validEndpoint(endpoint,location.protocol==='https:');url.search='';url.searchParams.set('social','1');
      this.status='CONNECTING';this.changed();const ws=this.ws=new WebSocket(url);
      ws.onmessage=async event=>{
        try{const m=JSON.parse(event.data);if(this.ws!==ws)return;
          if(m.type==='challenge'){
            const signature=await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},this.keys.privateKey,from64(m.value));
            if(ws.readyState===1)ws.send(JSON.stringify({type:'identify',pub:this.keys.pub,signature:to64(signature),name:this.name()}));
          }else if(m.type==='identity'){this.code=m.code;this.status='CONNECTED';this.sync();this.presenceStatus=null;this.setPresence(this.currentStatus||'LOBBY');}
          else if(m.type==='presence')this.presence=new Map((m.friends||[]).map(f=>[f.code,f]));
          else if(m.type==='invite'&&this.list.some(f=>f.code===m.from)){this.invitation={...m,received:Date.now()};}
          else if(m.type==='error')this.status=m.message;
          this.changed();
        }catch{this.status='Social connection error';this.changed();}
      };
      ws.onclose=()=>{if(this.ws!==ws)return;this.status='OFFLINE';this.code=this.code||'';this.presence.clear();clearInterval(this.heartbeat);this.changed();};
      ws.onerror=()=>{this.status='SERVER UNAVAILABLE';this.changed();};
      clearInterval(this.heartbeat);this.heartbeat=setInterval(()=>this.send({type:'ping'}),20000);
    }catch(e){this.status=e.message;this.changed();}
  }
  send(m){if(this.ws?.readyState===1)this.ws.send(JSON.stringify(m));}
  sync(){this.send({type:'friends',codes:this.list.map(f=>f.code)});}
  add(code,name){code=cleanCode(code);if(!validFriendCode(code)||code===this.code||this.list.some(f=>f.code===code)||this.list.length>=32)return false;this.list.push({code,name:String(name||'FRIEND').slice(0,16)});this.save();return true;}
  remove(code){this.list=this.list.filter(f=>f.code!==code);this.save();}
  save(){try{localStorage.setItem(LIST,JSON.stringify(this.list));}catch{this.status='Friend list cannot be saved.';}this.sync();this.changed();}
  setPresence(status){this.currentStatus=status;if(this.status!=='CONNECTED'||status===this.presenceStatus)return;this.presenceStatus=status;this.send({type:'presence',status});}
  invite(to){const code=roomCode(this.group());if(!code)return false;this.send({type:'invite',to,room:code});return true;}
  accept(){const i=this.invitation;this.invitation=null;this.changed();if(i&&Date.now()-i.received<120000)this.join(roomCode(i.room));}
  disconnect(){clearInterval(this.heartbeat);this.ws?.close();this.presence.clear();this.status='OFFLINE';this.changed();}
}
