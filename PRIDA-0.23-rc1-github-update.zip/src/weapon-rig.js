import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
const box=new T.BoxGeometry(1,1,1),cylinder=new T.CylinderGeometry(1,1,1,12),ring=new T.TorusGeometry(1,.17,6,12);
// Static receiver geometry is merged by material; the magazine, cylinder and bolt stay independently animated.
const templates=new Map();
function createWeapon(w,texture){
  if(w.melee||['handgrenade','c4','dagger'].includes(w.model))return null;
  const g=new T.Group(),body=new T.Group();g.add(body);
  const metal=new T.MeshStandardMaterial({color:0x626d72,metalness:.65,roughness:.4,map:texture('metal'),normalMap:texture('metal_n'),roughnessMap:texture('metal_arm')}),
    dark=new T.MeshStandardMaterial({color:0x2a3338,roughness:.72}),wood=new T.MeshStandardMaterial({color:0x9c8261,map:texture('oak'),roughness:.75}),
    glass=new T.MeshStandardMaterial({color:0x1f566c,roughness:.13,metalness:.8});
  metal.normalScale.set(.14,.14);
  const L=w.fp.len,pistol=['pistol','revolver','handcannon'].includes(w.model),tube=['rocket','grenadelauncher'].includes(w.model),bow=w.model==='crossbow',mini=w.model==='minigun';
  const part=(p,geo,m,x,y,z,a,b,c,rx=0)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);o.scale.set(a,b,c);o.rotation.x=rx;p.add(o);return o;};
  part(body,box,metal,0,0,0,pistol?.064:.086,pistol?.068:.11,L*(pistol?.8:.43));
  const grip=part(body,box,dark,0,-.107,L*.17,.064,.17,.08);grip.rotation.x=-.22;
  const guard=part(body,ring,metal,0,-.077,L*.035,.041,.028,.042,0);guard.rotation.y=Math.PI/2;
  if(!pistol){
    part(body,box,dark,0,-.018,L*.36,.075,.115,L*.20);
    part(body,box,dark,0,-.018,L*.48,.092,.16,.026);
    part(body,box,tube?metal:dark,0,.005,-L*.22,tube?.16:.10,tube?.16:.11,L*.29);
    for(let i=0;i<7;i++)part(body,box,metal,0,.070,-L*.28+i*L*.055,.095,.012,.016);
  }
  if(bow){
    for(const side of [-1,1]){const limb=part(body,box,dark,side*.19,0,-L*.30,.32,.025,.055);limb.rotation.y=-side*.4;}
    part(body,box,metal,0,.04,-L*.08,.012,.014,L*.70);
  }else if(mini){
    const barrels=new T.Group();barrels.position.z=-L*.15;body.add(barrels);
    for(let i=0;i<6;i++){const a=i/6*Math.PI*2;part(barrels,cylinder,metal,Math.cos(a)*.058,Math.sin(a)*.058,-L*.18,.014,L*.38,.014,Math.PI/2);}
    part(body,cylinder,dark,0,0,-L*.23,.087,.043,.087,Math.PI/2);g.userData.barrels=barrels;
  }else{
    part(body,cylinder,metal,0,tube?0:.009,-L*.38,tube?.072:pistol?.018:.018,L*.24,tube?.072:.018,Math.PI/2);
    part(body,cylinder,dark,0,tube?0:.009,-L*.498,tube?.056:.013,.003,tube?.056:.013,Math.PI/2);
  }
  const scope=['sniper','marksman','railgun','crossbow'].includes(w.model);
  if(scope){
    part(body,box,dark,0,.09,0,.028,.055,.09);
    part(body,cylinder,dark,0,.137,-L*.055,.036,L*.30,.036,Math.PI/2);
    for(const sign of [-1,1])part(body,cylinder,glass,0,.137,-L*.055+sign*L*.155,.030,.004,.030,Math.PI/2);
  }else if(!tube&&!mini){for(const z of [-L*.28,L*.21]){part(body,box,dark,0,pistol?.057:.093,z,.022,.040,.015);}}
  if(w.model==='railgun'){for(const side of [-1,1])part(body,box,metal,side*.042,.028,-L*.27,.021,.044,L*.42);}
  const cylinderReload=['revolver','handcannon'].includes(w.model),shells=w.model==='shotgun'||w.model==='grenadelauncher';
  if(!tube&&!bow&&!mini&&!cylinderReload&&!shells){
    const mag=part(g,box,dark,0,pistol?-.105:-.128,pistol?L*.17:-L*.07,.053,pistol?.145:.21,.074);mag.rotation.x=-.13;mag.userData.y=mag.position.y;g.userData.mag=mag;
  }
  if(cylinderReload){const cyl=part(g,cylinder,metal,0,-.01,-L*.01,.043,.082,.043,Math.PI/2);g.userData.cylinder=cyl;}
  if(shells||tube){const shell=part(g,cylinder,wood,.14,-.12,0,tube?.045:.013,tube?.24:.058,tube?.045:.013,Math.PI/2);shell.visible=false;g.userData.shell=shell;}
  const bolt=part(g,box,metal,.061,.018,L*.03,.065,.018,.018);g.userData.bolt=bolt;
  // Batch only direct body meshes; a minigun's rotating barrels remain a child group.
  const batches=new Map();for(const o of [...body.children])if(o.isMesh){o.updateMatrix();const geo=o.geometry.clone().applyMatrix4(o.matrix);if(!batches.has(o.material))batches.set(o.material,[]);batches.get(o.material).push(geo);body.remove(o);}
  for(const [m,geos]of batches){const merged=mergeGeometries(geos,false),o=new T.Mesh(merged,m);o.userData.weaponGeometry=true;body.add(o);for(const geo of geos)geo.dispose();}
  g.userData.length=L;g.userData.detailed=true;g.userData.weaponMaterials=[metal,dark,wood,glass];return g;
}

export function detailedWeapon(w,texture){
  if(w.melee||['handgrenade','c4','dagger'].includes(w.model))return null;
  let template=templates.get(w.model);
  if(!template){
    template=createWeapon(w,texture);
    for(const key of ['mag','cylinder','shell','bolt','barrels'])if(template.userData[key]){template.userData[key].name='Part_'+key;delete template.userData[key];}
    delete template.userData.weaponMaterials;templates.set(w.model,template);
  }
  const copy=template.clone(true);
  for(const key of ['mag','cylinder','shell','bolt','barrels']){const part=copy.getObjectByName('Part_'+key);if(part)copy.userData[key]=part;}
  return copy;
}
