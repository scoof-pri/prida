import * as T from 'three';
import { groundHeight } from './terrain.js';
import { castMap } from './raycast.js';
export class BallisticsView{
  constructor(view){
    this.view=view;this.pools=[];this.matrix=new T.Matrix4();this.quat=new T.Quaternion();this.scale=new T.Vector3();this.pos=new T.Vector3();
    for(const [kind,cap,geo,mat] of [['brass',120,new T.CylinderGeometry(.012,.012,.064,8),new T.MeshStandardMaterial({color:0xc49c44,metalness:.8,roughness:.35})],['mag',16,new T.BoxGeometry(.052,.17,.083),new T.MeshStandardMaterial({color:0x414c53,metalness:.4,roughness:.6})]]){
      const mesh=new T.InstancedMesh(geo,mat,cap);mesh.instanceMatrix.setUsage(T.DynamicDrawUsage);mesh.frustumCulled=false;mesh.castShadow=true;view.scene.add(mesh);mesh.count=0;this.pools.push({kind,cap,mesh,list:[],next:0});
    }
  }
  emit(kind,origin,velocity){
    const pool=this.pools.find(p=>p.kind===kind);const floor=castMap(origin,{x:0,y:-1,z:0},4,this.view.map),y=floor.impact?origin.y-floor.distance:groundHeight(origin.x,origin.z,this.view.map);
    const item={...origin,vx:velocity.x,vy:velocity.y,vz:velocity.z,t:0,max:kind==='mag'?4:2.7,angle:0,spin:8+Math.random()*9,floor:y,seed:Math.random()*6};
    if(pool.list.length<pool.cap)pool.list.push(item);else pool.list[pool.next++%pool.cap]=item;
  }
  update(dt){
    for(const p of this.pools){let n=0;
      for(let i=p.list.length-1;i>=0;i--){const r=p.list[i];r.t+=dt;if(r.t>r.max){p.list.splice(i,1);continue;}
        r.vy-=9.8*dt;r.x+=r.vx*dt;r.y+=r.vy*dt;r.z+=r.vz*dt;r.angle+=r.spin*dt;
        if(r.y<r.floor+.025){r.y=r.floor+.025;r.vy=Math.abs(r.vy)*.31;r.vx*=.66;r.vz*=.66;r.spin*=.7;}
        const fade=Math.min(1,(r.max-r.t)*3);this.scale.setScalar(fade);this.pos.set(r.x,r.y,r.z);this.quat.setFromEuler(new T.Euler(r.angle,r.seed,r.angle*.4));this.matrix.compose(this.pos,this.quat,this.scale);p.mesh.setMatrixAt(n++,this.matrix);
      }
      p.mesh.count=n;p.mesh.instanceMatrix.needsUpdate=true;
    }
  }
  reset(){for(const p of this.pools){p.list=[];p.mesh.count=0;}}
  dispose(){for(const p of this.pools){p.mesh.removeFromParent();p.mesh.geometry.dispose();p.mesh.material.dispose();p.mesh.dispose();}}
}
