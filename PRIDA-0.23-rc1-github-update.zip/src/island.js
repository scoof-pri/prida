// Deterministic island layout shared by client, server, physics and the map UI.
// No renderer objects or random global state belong in this module.
const smooth = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
export const ISLAND_TOWNS = [
  { name: 'PRIDA CENTRAL', x: 0, z: 0, w: 264, d: 208, kind: 'city' },
  { name: 'PINEGATE', x: -312, z: -182, w: 144, d: 104, kind: 'forest' },
  { name: 'RED MESA', x: 264, z: -156, w: 144, d: 104, kind: 'desert' },
  { name: 'TIDAL PORT', x: 192, z: 234, w: 168, d: 104, kind: 'harbor' },
  { name: 'HARVEST FIELDS', x: -240, z: 234, w: 144, d: 104, kind: 'farm' },
  { name: 'NORTHWATCH', x: 0, z: -312, w: 120, d: 104, kind: 'research' },
];
export function makeIsland(seed) {
  return { rx: 535, rz: 466, water: -0.7, phase: (seed % 997) / 997 * 0.55 };
}
export function coastRadius(angle, island) {
  const a = angle + island.phase;
  return 1 + 0.067 * Math.sin(a * 3 + 0.6) + 0.045 * Math.sin(a * 5 - 0.8) + 0.023 * Math.cos(a * 9);
}
// Positive values are inland, in approximate metres. Concave coves are intentional.
export function coastDistance(x, z, map) {
  if (!map.island) return Infinity;
  const i = map.island, xx = x / i.rx, zz = z / i.rz, a = Math.atan2(zz, xx);
  return (coastRadius(a, i) - Math.hypot(xx, zz)) * Math.min(i.rx, i.rz);
}
export function coastPolygon(map, count = 180, inset = 0) {
  return Array.from({ length: count }, (_, n) => {
    const a = n / count * Math.PI * 2, r = coastRadius(a, map.island) - inset / Math.min(map.island.rx, map.island.rz);
    return { x: Math.cos(a) * map.island.rx * r, z: Math.sin(a) * map.island.rz * r };
  });
}
export function riverX(z) { return -65 + Math.sin((z - 105) / 70) * 26; }
export function riverDistance(x, z) {
  if (z < 105 || z > 505) return Infinity;
  return Math.abs(x - riverX(z));
}
export function isDryLand(x, z, map, margin = 0) {
  return !map.island || (coastDistance(x, z, map) > 9 + margin && (riverDistance(x, z) > 7 + margin || Math.abs(z - 208) < 7));
}
export function islandHeight(x, z, map) {
  if (!map.island) return 0;
  const coast = coastDistance(x, z, map);
  let y = -10 * (1 - smooth(-35, 20, coast));
  const rd = riverDistance(x, z);
  if (rd < 11) y = Math.min(y, -2.8 * (1 - smooth(5.5, 11, rd)) * smooth(105, 120, z));
  return y;
}
function townAt(x, z, pad = 0) {
  return ISLAND_TOWNS.find(p => Math.abs(x - p.x) <= p.w / 2 + pad && Math.abs(z - p.z) <= p.d / 2 + pad);
}
export function reserveIslandLots(map, grid) {
  const { cols: C, rows: R, x0, z0 } = map.grid;
  map.pois = ISLAND_TOWNS.map(p => ({ ...p }));
  map.pois.push({ name: 'STONECROWN', x: -190, z: -300, kind: 'mountain' }, { name: 'SILENT LAGOON', x: -60, z: 135, kind: 'lake' });
  // Reserve all wilderness before the original building generator allocates connected city plots.
  for (let ca = 0; ca < C; ca += 2) for (let ra = 0; ra < R; ra += 2) {
    const cells = [];
    for (let c = ca; c < Math.min(C, ca + 2); c++) for (let r = ra; r < Math.min(R, ra + 2); r++) {
      const x = x0 + 12 + c * 24, z = z0 + 13 + r * 26;
      if (!(townAt(x, z) && isDryLand(x, z, map, 22))) cells.push(c * R + r);
    }
    if (!cells.length) continue;
    // Partial blocks become individual natural plots; full 2x2 blocks remain contiguous wilderness.
    for (const set of cells.length === 4 ? [cells] : cells.map(i => [i])) {
      const cs = set.map(i => Math.floor(i / R)), rs = set.map(i => i % R),
        c0 = Math.min(...cs), c1 = Math.max(...cs) + 1, r0 = Math.min(...rs), r1 = Math.max(...rs) + 1,
        x = x0 + (c0 + c1) * 12, z = z0 + (r0 + r1) * 13,
        shore = coastDistance(x, z, map),
        type = shore < 0 ? 'ocean' : shore < 45 ? 'coast' :
          (Math.hypot(x + 60, z - 135) < 53 ? 'lake' : x > 170 ? 'desert' : x < -135 || z < -210 ? 'forest' : z > 160 ? 'meadow' : 'glade'),
        id = map.plots.length,
        p = { id, x, z, w: (c1 - c0) * 24, d: (r1 - r0) * 26, cells: set, cols: c1 - c0, rows: r1 - r0, type };
      for (const i of set) grid[i] = id;
      map.plots.push(p);
      if (type !== 'ocean') map.parks.push(p);
    }
  }
  // Broad hills between, not beneath, settlements. Their bases blend into the forest.
  map.hills.push({ x: -190, z: -300, radius: 67, height: 36 }, { x: -250, z: -310, radius: 50, height: 19 });
}
export function islandRoads(map) {
  const add = (ax, az, bx, bz) => {
    const alongX = Math.abs(bx - ax) >= Math.abs(bz - az), len = alongX ? Math.abs(bx - ax) : Math.abs(bz - az),
      steps = Math.ceil(len / 12);
    for (let k = 0; k < steps; k++) {
      const t = (k + .5) / steps, x = ax + (bx - ax) * t, z = az + (bz - az) * t;
      if (coastDistance(x, z, map) < 22) continue;
      map.roads.push({ x, z, w: alongX ? len / steps + .1 : 6, d: alongX ? 6 : len / steps + .1, arterial: true });
    }
  };
  // Connected roads use the actual 24x26 m grid boundaries so they meet town streets cleanly.
  const routes = [
    [[0, 0], [-144, 0], [-144, -156], [-312, -156]],
    [[0, 0], [144, 0], [144, -156], [264, -156]],
    [[0, 0], [0, -312]],
    [[0, 0], [144, 0], [144, 208], [264, 208]],
    [[0, 0], [-144, 0], [-144, 208], [-312, 208]],
    [[-144, 208], [144, 208]],
  ];
  for (const points of routes) for (let k = 1; k < points.length; k++) add(...points[k - 1], ...points[k]);
  // River, with a solid bridge where the southern cross-island road passes over it.
  for (let z = 118; z < 510; z += 7) map.waters.push({ x: riverX(z), z, w: 13, d: 9, y: -.62, river: true });
  const x = riverX(208), bridge = { x, z: 208, y: -.12, w: 29, h: .3, d: 8, part: 'bridge', color: 0x7e766b };
  map.obstacles.push(bridge);
  for (const side of [-1, 1]) map.obstacles.push({ x, z: 208 + side * 4.1, y: .52, w: 29, h: .95, d: .2, part: 'bridge', color: 0x727780 });
}
// Flatten hill contributions along roads, without scanning every road for every terrain vertex.
export function roadHillFactor(x, z, map) {
  if (!map.island) return 1;
  if (!map._roadHeightGrid || map._roadHeightGrid.count !== map.roads.length) {
    const buckets = new Map();
    for (const r of map.roads) for (let a = Math.floor((r.x - r.w / 2 - 5) / 32); a <= Math.floor((r.x + r.w / 2 + 5) / 32); a++)
      for (let b = Math.floor((r.z - r.d / 2 - 5) / 32); b <= Math.floor((r.z + r.d / 2 + 5) / 32); b++) {
        const key = a + ':' + b; if (!buckets.has(key)) buckets.set(key, []); buckets.get(key).push(r);
      }
    map._roadHeightGrid = { count: map.roads.length, buckets };
  }
  let f = 1;
  for (const r of map._roadHeightGrid.buckets.get(Math.floor(x / 32) + ':' + Math.floor(z / 32)) || []) {
    const d = Math.max(Math.abs(x - r.x) - r.w / 2, Math.abs(z - r.z) - r.d / 2);
    f = Math.min(f, smooth(1, 5, d));
  }
  return f;
}
