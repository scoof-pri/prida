// Final clearance pass includes interactive doors and lift shafts, which are added after furniture.
export function settleChests(map){
  const free=(x,y,z,skip)=>{
    let clear=true;
    map.obstacles.grid.query(x-.75,z-.65,x+.75,z+.65,o=>{
      if(!clear||o.nocollide||o.part==='pond'||o.y+o.h/2<y+.055||o.y-o.h/2>y+.88)return;
      if(Math.abs(x-o.x)<o.w/2+.66&&Math.abs(z-o.z)<o.d/2+.46)clear=false;
    });
    if(clear&&map.chests.some(c=>c!==skip&&Math.abs((c.y||0)-y)<.8&&Math.hypot(x-c.x,z-c.z)<1.25))clear=false;
    return clear;
  };
  for(const c of map.chests){
    if(c.building===undefined&&c.id.startsWith('chest'))c.building=Number(c.id.slice(5));
    const y=c.y||0,b=map.buildings[c.building];if(free(c.x,y,c.z,c))continue;
    let found=null;
    for(let r=.8;r<=8&&!found;r+=.8)for(let k=0;k<16;k++){
      const a=k/16*Math.PI*2,x=c.x+Math.cos(a)*r,z=c.z+Math.sin(a)*r;
      if(b&&(Math.abs(x-b.x)>b.w/2-1||Math.abs(z-b.z)>b.d/2-1))continue;
      if(free(x,y,z,c)){found={x,z};break;}
    }
    if(found)Object.assign(c,found);
  }
}
