# PRIDA handoff — 0.23.0-rc.1

## Exact source lineage

Repository: `scoof-pri/prida`. Main baseline: `1f2a52be871006009dd5bf4383134ced9e888be7` (0.20.0). The starting working branch was `feature/island-combat-021`, head `9f145c3dd58b6a3481923015d59cfe62fdd5745d`, draft PR #1. The current RC work is in the files shipped with this archive. It has NOT been pushed to GitHub or deployed. The full archive retains the existing Git history, with the new changes present in its working tree; do not assume HEAD is the release commit.

## New and changed module map

- `island.js` / `world.js` / `terrain.js`: seed-deterministic irregular coast, six towns, river, bridge, road flattening, 4 m island terrain grid (district stays 2 m). Bounds 1200 × 1080 m including sea. Seed 91726: 191 buildings, 30 types, 228 chests, 598 doors, 22 lifts, 3051 trees. These counts are seed-specific.
- `loot-placement.js` / `chests.js`: final physical clearance of floor-aware chest positions; original opaque four-batch chest body/trim/lid geometry with inner and outer faces. No alpha/transparent chest material.
- `ordnance.js` / `simulation.js`: bounded substeps, swept casts, fuse, bounce, C4 sticking/arming/ownership/expiry; T detonation; personal shield/cells/J; ARC LANCE penetration. Original weapon IDs remain 0–16, new IDs 17–19.
- `interactions.js`: sliding door colliders and numbered flat doors; lift platforms/gates/shafts, safe closure, carrying players, destruction and network mirror. `interaction-view.js`: instanced visuals/nearby labels. `E` first checks nearby loot, then door/lift interaction.
- `cells.js` / `destruction.js` / `scenery.js`: fine 4³ subvoxels, hexadecimal masks, matching ray/collision/visible geometry. Coarse slab and heavy-weapon destruction remain.
- `operators.js` / `assets.js`: three procedural tactical operators with 17 compatible named animation clips. `creatures.js` / `boss-view.js`: five different non-robot creatures reading authoritative ability telegraphs. Bus materials/interior/hatch were extended.
- `weapon-rig.js`: shared immutable detailed weapon geometry, separate magazine/cylinder/shell/bolt transforms. `gadget-models.js` plus `scripts/build-gadgets.mjs`: local GLBs for hand grenade/C4/railgun; matching icons in `public/icons`.
- `ballistics-view.js`: bounded instanced brass and dropped-mag pools, gravity/bounce/fade. `render.js`: reload motion, poses, local legs, camera bob/drop lean, muzzle flash/light. `effects.js`: textured chunk debris instead of plain white cubes.
- `lobby-view.js`: same WebGL renderer, separate inexpensive preview scene. `main.js`/`index.html`/`style.css`: wardrobe preview, revised lobby, HUD, shield and tactical controls, damage feedback, touch layout. Preview operator faces the camera; ordinary world actors retain authoritative yaw.
- `friends.js` / `social-server.mjs`: device-local P-256 identity, nonce authentication, bounded mutual presence and group invites via existing server. `/config.json` and endpoint UI remain the only server-address sources. Client-generated private identity keys stay in device storage and are never sent to the server. They are not embedded credentials.
- `server.mjs` / `room.js`: new authoritative fields automatically included. Unchanged chests/destruction/doors/lifts can be omitted from delta packets; `main.js` retains the last copy. JPEG/WebP response MIME types fixed.

## Invariants

English-only UI, PRIDA title, exact credit `made by mark pridachin`; first-person game; PC/touch; bots visibly BOT; 10/24 contenders; solo-only codes with no rewards; no paid services, account secrets or invented endpoints. Existing asset licences must stay included.

## Verify before public release

Read `QA-REPORT.md`, then run `npm ci`, `npm test`, `npm run build`, `npm start` on Node 22. Use the built app through localhost:8080 or HTTPS. Exercise a full match and a two-browser online/P2P session, inspect chest opacity at several viewpoints, every new weapon, apartment/lift access, collapse during movement, the wardrobe, all boss attacks, and portrait/landscape touch devices. This environment allowed simulation/network tests and DOM-only layout screenshots, not a real WebGL frame; do not mark that final pass done.

The new implementations cover the main remake systems, but photorealistic art/polish, basement excavation, a drone/deployable shield wall and replacing all legacy furniture/car meshes have not been delivered. Retained Kenney geometry is still present. Do not infer those features from the earlier wish list. The old Claude artifact and live Render deployment have not been updated.

## Deliverables

The GitHub update ZIP contains additions/modifications relative to main, with folder paths and no enclosing directory. Unzip and upload the files/folders, not the ZIP itself. No tracked files are deleted by this update. The full ZIP contains project source, existing Git history and the production dist, but not node_modules or credentials. `RELEASE-MANIFEST.json` lists update paths and SHA-256 digests. Keep client/server versions together.
