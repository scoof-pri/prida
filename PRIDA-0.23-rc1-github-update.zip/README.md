# PRIDA — 0.23.0-rc.1

First-person browser battle royale by Mark Pridachin. English UI; keyboard/mouse and touch controls. Three.js 0.180, Rapier 0.19, Vite 7, and an optional authoritative Node/WebSocket server. No real-money purchases or embedded service secrets.

## Run

Use Node 22 and the checked-in lockfile:

```sh
npm ci
npm test
npm run build
npm start
```

The server listens on port 8080 by default and serves `dist/`. Open `http://localhost:8080` for the built game, multiplayer and friends on one origin. `npm run dev` starts the Vite development frontend; its port is not a multiplayer server. Friends require HTTPS or localhost plus persistent browser storage.

The source archives do not include `node_modules`. `npm ci` downloads the dependencies. The full archive includes the production `dist/` files as a convenience, but running the Node server still requires its dependencies. Opening `index.html` with `file://` is not a supported way to run the game.

## What changed

- **Island Royale:** 1,200 × 1,080 m world bounds, not 1.296 km² of dry land. An irregular coastline surrounds six separated settlements, hills, forest, meadow, desert, a lagoon, a river and a solid bridge. The sea and river shape rendering, physics, spawn and navigation rules. The minimap and inventory map share the same coastline and orientation. Internal protocol key remains `city` / `royale-city`.
- **Combat:** 20 weapon entries; the old 17 indices are preserved. Added thrown hand grenades, sticky remote C4 and ARC LANCE (up to two thin walls, reduced power after penetration). At most three active C4 charges per owner; arming delay, expiry and owner cleanup are enforced by the simulation. Persistent shield HP is separate from temporary spawn protection. Shield cells restore 50 points over two seconds, capped at 100.
- **World interactions:** opaque, thick-walled chests with separately animated lids; rarities and scarcer floor-aware loot. Numbered apartment doors slide with their colliders. Lift shafts have landing gates, call/next-floor controls, moving platforms, rider transport and doorway safety checks. Lifts and doors are mirrored to network clients and removed after structural collapse.
- **Destruction:** weak bullet impacts use 4 × 4 × 4 micro-cells inside a coarse wall cell. Geometry, ray tests and colliders use the same carved volume; compact masks are sent over the network. Heavy weapons still remove larger wall pieces.
- **Presentation:** procedural adult-proportioned tactical operators, five different non-robot boss creatures, original detailed weapon rigs, bus interior additions, reload parts/ejected magazines, brass casings, textured debris, muzzle flashes, locomotion/gliding/drop poses and camera motion. These are lightweight procedural assets, not photogrammetric or cinematic production assets. Existing car and furniture meshes are retained with the project's PBR materials.
- **Lobby/HUD:** 3D character turntable and on-character cosmetic previews, emotes, English item cards, health/shield bars, rarity weapon slots, hit feedback and damage numbers. The preview reuses the main WebGL renderer rather than adding a second graphics context.
- **Friends:** locally stored device identity and friend list, signed login challenges, mutual online status, invitations into existing groups. No account service. Both players add each other's codes and connect to the same PRIDA server. Clearing browser storage loses that device identity/list; presence is not a cloud backup.

## Controls

WASD moves; mouse looks; left mouse fires, throws or places; right mouse aims. Space jumps or deploys equipped air gear; Shift sprints. Keys 1–5, mouse wheel and Q select weapons. R reloads. **T detonates armed C4. J uses a shield cell. E opens a chest/door, calls a lift, or selects the next floor while inside it.** H heals, F/G use relics, B emotes, V dashes when unlocked, I/M/Tab opens inventory/map, Esc pauses. Touch equivalents are on screen.

## Modes and compatibility

Mini Royale has 10 contenders; Island Royale has 24. Online Island Royale allows up to 10 human players and fills the remaining places with bots. All bots are marked BOT. Training and Survival remain available. Private groups retain the existing WebRTC host path; public matchmaking uses the Node server.

**Deploy client and server from this release together.** The new shield, remote ordnance, micro-damage and interactive geometry state must not be mixed with an older server. The matching server serves `/config.json` with same-origin configuration; do not add a guessed WebSocket URL. Existing `Dockerfile` and `render.yaml` are retained. This archive has not been deployed to the live site.

Solo sandbox codes 250886 and 112358 remain solo-only and turn off rewards. They do not enable server cheats. Cosmetics, pass tiers and skills remain earned with in-game rewards.

## Verification and scope

See `QA-REPORT.md` for actual test/build results and unverified areas. RC1 is not a claim of final visual/device acceptance. WebGL gameplay could not be inspected in the current browser environment; DOM layout was inspected independently. No new FPS or latency benchmark is claimed.

Basement excavation, a deployable shield wall, a drone weapon and a full replacement of the existing car/furniture meshes are not included. The delivered shield is a personal damage-absorption mechanic. The island is original PRIDA layout, not a copied Fortnite map.

`UPDATE-RU.md` explains ZIP installation. `HANDOFF.md` maps the new modules. Earlier development notes are preserved in `docs/history/README-0.20.md`. Asset attributions and the original third-party notices remain in `public/ASSET-CREDITS.md` and `public/licenses/`.
