// Rebuild original equipment GLBs without a browser or external downloads.
import { Document, NodeIO } from '@gltf-transform/core';
import { gadgetModel } from '../src/gadget-models.js';
const io = new NodeIO();
for(const name of ['handgrenade','c4','railgun']) {
  const doc = new Document(), buffer = doc.createBuffer(), scene=doc.createScene();
  const root=gadgetModel(name); root.updateMatrixWorld(true);
  const materials=new Map();
  root.traverse(o=>{
    if(!o.isMesh)return;
    const g=o.geometry.clone().applyMatrix4(o.matrixWorld), m=o.material;
    if(!materials.has(m)) materials.set(m,doc.createMaterial().setBaseColorFactor([m.color.r,m.color.g,m.color.b,1]).setMetallicFactor(m.metalness).setRoughnessFactor(m.roughness).setEmissiveFactor([m.emissive.r*m.emissiveIntensity,m.emissive.g*m.emissiveIntensity,m.emissive.b*m.emissiveIntensity]));
    const prim=doc.createPrimitive().setMaterial(materials.get(m));
    for(const [a,semantic,type] of [['position','POSITION','VEC3'],['normal','NORMAL','VEC3'],['uv','TEXCOORD_0','VEC2']])
      if(g.attributes[a])prim.setAttribute(semantic,doc.createAccessor().setType(type).setArray(new Float32Array(g.attributes[a].array)).setBuffer(buffer));
    if(g.index)prim.setIndices(doc.createAccessor().setType('SCALAR').setArray(new Uint16Array(g.index.array)).setBuffer(buffer));
    scene.addChild(doc.createNode(o.name||name).setMesh(doc.createMesh().addPrimitive(prim))); g.dispose();
  });
  await io.write('public/models/'+name+'.glb',doc);
}
