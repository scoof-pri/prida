// Per-device public-key identities. The server receives no private key; presence requires mutual consent.
import { randomBytes, createHash, createPublicKey, verify } from 'node:crypto';
const codeOf=pub=>createHash('sha256').update(pub).digest('hex').slice(0,24).toUpperCase();
const validCode=x=>typeof x==='string'&&/^[A-F0-9]{24}$/.test(x);
export class SocialService {
  constructor(){this.peers=new Map();}
  send(ws,data){if(ws.readyState===1&&ws.bufferedAmount<16000)ws.send(JSON.stringify(data));}
  publish(){
    for(const [id,p] of this.peers){
      const friends=[...p.friends].map(code=>{const q=this.peers.get(code),mutual=q?.friends.has(id);return {code,online:!!mutual,name:mutual?q.name:undefined,status:mutual?q.status:undefined};});
      this.send(p.ws,{type:'presence',friends});
    }
  }
  connect(ws){
    if(this.peers.size>=200){ws.close(1013,'Social capacity reached');return;}
    const challenge=randomBytes(32).toString('base64');let identity=null,rate=15,at=Date.now(),lastInvite=0;
    ws.alive=true;ws.on('pong',()=>ws.alive=true);
    const timeout=setTimeout(()=>{if(!identity)ws.close(1008,'Identity handshake expired');},10000);timeout.unref?.();
    this.send(ws,{type:'challenge',value:challenge});
    ws.on('message',raw=>{
      ws.alive=true;const now=Date.now();rate=Math.min(15,rate+(now-at)/1000);at=now;if(--rate<0){ws.close(1008,'Social rate limit');return;}
      try{
        const m=JSON.parse(raw.toString());
        if(!identity){
          if(m.type!=='identify'||typeof m.pub!=='string'||m.pub.length>400||typeof m.signature!=='string'||m.signature.length>200)return;
          const bytes=Buffer.from(m.pub,'base64'),key=createPublicKey({key:bytes,format:'der',type:'spki'});
          if(key.asymmetricKeyType!=='ec'||key.asymmetricKeyDetails?.namedCurve!=='prime256v1'||!verify('sha256',Buffer.from(challenge,'base64'),{key,dsaEncoding:'ieee-p1363'},Buffer.from(m.signature,'base64'))){ws.close(1008,'Invalid signature');return;}
          identity=codeOf(bytes);clearTimeout(timeout);const old=this.peers.get(identity);if(old)old.ws.close(1000,'Connected on another tab');
          this.peers.set(identity,{ws,name:String(m.name||'PLAYER').replace(/[<>\x00-\x1f]/g,'').slice(0,16),friends:new Set(),status:'LOBBY'});
          this.send(ws,{type:'identity',code:identity});return;
        }
        const p=this.peers.get(identity);if(p?.ws!==ws)return;
        if(m.type==='friends'){
          p.friends=new Set((Array.isArray(m.codes)?m.codes:[]).filter(x=>validCode(x)&&x!==identity).slice(0,32));this.publish();
        }else if(m.type==='presence'){
          p.status=['LOBBY','IN MATCH','IN GROUP'].includes(m.status)?m.status:'LOBBY';this.publish();
        }else if(m.type==='invite'){
          const q=this.peers.get(m.to);
          if(now-lastInvite<3000||!q||!p.friends.has(m.to)||!q.friends.has(identity)||typeof m.room!=='string'||!/^[A-Z0-9_-]{3,24}$/.test(m.room))return;
          lastInvite=now;this.send(q.ws,{type:'invite',from:identity,name:p.name,room:m.room});
        }else if(m.type==='ping')this.send(ws,{type:'pong'});
      }catch{this.send(ws,{type:'error',message:'Invalid social message.'});}
    });
    ws.on('close',()=>{clearTimeout(timeout);if(this.peers.get(identity)?.ws===ws){this.peers.delete(identity);this.publish();}});
  }
}
export { codeOf };
