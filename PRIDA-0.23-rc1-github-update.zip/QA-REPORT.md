# PRIDA 0.23.0-rc.1 — verification report

Date: 2026-09-25. Source: main baseline `1f2a52be871006009dd5bf4383134ced9e888be7`, then the existing `feature/island-combat-021` work through `9f145c3dd58b6a3481923015d59cfe62fdd5745d`, then the unpushed changes in this archive. This is not a report of the currently deployed website.

## Completed checks

**Automated tests: 143 passed, 0 failed, 0 skipped.** Command: `npm test`; Node 22.16.0. Total runtime approximately 37.6 seconds in this environment. Raw results: `docs/qa/tests.txt`. Tests include original simulation/network/P2P invariants and new focused regressions. Old tests whose assumptions changed (weapon count, rectangular map, every chest being on the ground, immediate explosion of the new timed grenade) were updated; they were not simply disabled.

Coverage includes chest interior/exterior faces and opaque depth-writing materials; chest pool resizing and lid transforms; deterministic island geometry, dry spawn/loot positions, bridge and terrain/collider heights; floor-aware loot clearance; grenade bounce/fuse/one explosion; C4 arming, owner, active limit, expiry and cleanup; shield timing, cap, absorption and cancellation; door collision and anti-crush reopening; moving lift rider carry/network mirroring/collapse; micro-crater masks and geometry volume; rail penetration; input expiry and invalid dt; operator animation tracks; independent reload parts; distinct boss meshes; signed friend identities, mutual presence, invitations, disconnect cleanup and rejected forged identities. These are code/geometry/simulation checks, not judgments of final art quality.

**Production build: passed.** Command: `npm run build`. 68 modules transformed. Bundled JS approximately 3,223.83 kB (gzip 1,126.61 kB); CSS 48.45 kB (gzip 11.19 kB); HTML 27.30 kB. Vite warns that the JS chunk is larger than 3,000 kB. The warning is retained, not suppressed, and is not a build failure. Raw output: `docs/qa/build.txt`.

**Built Node server smoke check: passed.** `/health` reported PRIDA; the built index, same-origin configuration, JPEG/WebP textures and all three new GLB files returned HTTP 200 with their expected MIME types. Results: `docs/qa/http-smoke.json`.

**DOM/CSS layout check: completed separately from the game.** Chromium rendered static HTML/CSS at 1280×720, 390×844 and 844×390. This revealed an old top anchor stretching the inventory button and overlaps between touch buttons and vitals. They were corrected. The check deliberately excluded the game scripts, WebGL canvas and loaded models, so it does NOT establish a successful game boot. Bounds recorded in `docs/qa/ui-layout.json` are layout-only evidence.

## Known limitations / acceptance still required

No actual WebGL frame or full browser match was successfully inspected. The available browser environment blocked local navigation and did not provide a usable WebGL context. Do not claim final visual acceptance, a tested mobile frame rate, absence of rendering regressions, or a measured improvement in latency. No physical Android/iOS playtest was performed. Node/WebSocket tests are not a substitute for a two-human internet/P2P match.

The model/animation pass is original lightweight procedural work; it is not photorealistic or a finished cinematic animation library. Existing car/furniture meshes are retained with the project's material system. Basement excavation, a drone weapon and a deployable shield wall are not implemented. Personal shield HP/cells are implemented. Scarcer loot uses outdoor and upper-floor positions; no claim is made that every suggested placement from the earlier wish list exists.

Before treating RC1 as a public release, run the built game on a normal WebGL2 browser and inspect: lobby appearance and cosmetic previews; each operator/boss/weapon; chest opacity from outside/inside and after opening; door/lift interaction on each floor and during destruction; actual reload/particle appearance; bus drop, glider and jetpack; a complete island match; a server/P2P match; mutual friend invitations; portrait/landscape touch controls and real-device memory/frame time.

## Deployment and artifacts

Main, PR #1 and the live Render/Claude artifact have not been updated by this local release work. The GitHub ZIP is an update against main, not only against the already-partial feature branch. Upload/merge and deploy client/server together. See `UPDATE-RU.md`. The full archive contains the existing Git history with these changes in its working tree, plus the production dist. No dependency directory, service credentials or system font files are included.
