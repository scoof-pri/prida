// Checks a production build (no dev hook): boots the page, starts a solo match, plays a few seconds and
// grabs the canvas in a rAF callback (runs after the game's own render, before compositing).
import { writeFileSync } from 'node:fs';
import { deflateSync, crc32 } from 'node:zlib';
function png(w, h, rgba) {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) rgba.copy(raw, y * (w * 4 + 1) + 1, (h - 1 - y) * w * 4, (h - y) * w * 4);
  const chunk = (type, data) => {
    const len = Buffer.alloc(4), crc = Buffer.alloc(4), td = Buffer.concat([Buffer.from(type), data]);
    len.writeUInt32BE(data.length); crc.writeUInt32BE(crc32(td) >>> 0);
    return Buffer.concat([len, td, crc]);
  };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
export default async (page) => {
  await page.goto(process.env.URL || 'http://127.0.0.1:5174/');
  await page.waitForSelector('#menu:not(.hidden)', { timeout: 180000 });
  console.log('menu ok');
  await page.evaluate(() => { document.querySelector('#gameMode').value = 'classic'; document.querySelector('#train').click(); });
  await page.waitForSelector('#hud:not(.hidden)', { timeout: 300000 });
  console.log('match started');
  await page.waitForTimeout(Number(process.env.WAIT || 20000));
  const r = await page.evaluate(() => new Promise((res) => {
    requestAnimationFrame(() => {
      const c = document.querySelector('#game'), gl = c.getContext('webgl2') || c.getContext('webgl');
      const w = gl.drawingBufferWidth, h = gl.drawingBufferHeight, px = new Uint8Array(w * h * 4);
      gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, px);
      let bin = '';
      for (let i = 0; i < px.length; i += 0x8000) bin += String.fromCharCode.apply(null, px.subarray(i, i + 0x8000));
      res({ w, h, data: btoa(bin), fps: document.querySelector('#timer')?.textContent, hint: document.querySelector('#health')?.textContent });
    });
  }));
  writeFileSync((process.env.OUT || '/home/claude/work/shots/') + 'prod.png', png(r.w, r.h, Buffer.from(r.data, 'base64')));
  delete r.data;
  console.log('GRAB', JSON.stringify(r));
};
