# PRIDA — full baseline for a new chat (state: 0.20.1, stage 1 of 4 done)

> **Как пользоваться (RU).** Этот файл — полный контекст проекта. Вставь его в новый чат (ChatGPT/Claude) вместе с
> архивом `PRIDA-0.20-full.zip` (весь проект с историей git). В файле: что за игра, жёсткие правила, карта кода,
> команды, что уже сделано в версии 0.20 (этап 1 из 4) и что осталось сделать в этапах 2–4. Отвечать пользователю
> нужно по-русски и коротко; интерфейс игры — только по-английски.

---

## 1. What the game is

- **PRIDA**: a low-poly, first-person battle-royale shooter for the browser (PC and mobile). Target platform: CrazyGames.
- Author: Mark Pridachin (user "Yuri", pridachin@gmail.com). Lives in Turkey, writes in Russian, often with typos or in
  the wrong keyboard layout ("cnjq" = "стой").
- **Stack**: Three.js 0.180, Rapier 3D (`@dimforge/rapier3d-compat` 0.19), Vite 7, a Node WebSocket server (`ws`),
  tests with Node's built-in `node --test`. No framework, no bundlers besides Vite, no TypeScript.
- Repository: **github.com/scoof-pri/prida** (public). The user uploads files through the **GitHub web UI**
  (max 100 files per upload), so always hand him a zip of the *changed* files with their folder paths, plus a full zip.
- Hosting: **Render free web service "prida"** — region Frankfurt, runtime Docker, URL https://prida.onrender.com,
  auto-deploy on commit. `/health` returns stepMs, worstStepMs, loopLagAvgMs, loopLagMaxMs, heapMB, rssMB, uptimeS.
- The user wants **free hosting that needs no bank card**. PHP hosts (InfinityFree) cannot run the Node server.
  Private groups use direct WebRTC play (0.15) to avoid server lag.

## 2. Hard rules (keep them in every version)

- The name is **PRIDA**, the UI is **English only**. The lobby credit reads exactly **"made by mark pridachin"**.
  `tests/prida.test.mjs` asserts that `index.html`, `src/main.js`, `src/catalog.js`, `src/assets.js` contain no Cyrillic,
  that `index.html` has `<html lang="en">`, the credit string and a `<title>PRIDA…`.
- First-person view; must work on PC (mouse/keyboard) and on mobile (touch buttons).
- Mini Royale = 10 contenders. Big City Royale = 24 in solo, up to 10 humans online (bots fill the rest).
- **Bots are always labelled BOT.** Never present them as online players.
- Cheat code **250886** (flight, infinite ammo, god mode) works only in solo, never on the server, and turns off rewards.
  Bazooka code **112358** is solo only too.
- **Never invent a server address and never put secrets in the client.**
- Free hosting only. Nothing is sold for real money: coins, the battle pass and skills are earned by playing.
- Workflow the user expects:
  - split big requests into stages and deliver **one stage per message** unless he says "do all" ("сделай всё");
  - reply **in Russian**, keep replies short;
  - give a **GitHub-update zip** (changed files with folder paths) **plus a full zip**, and **republish the playable
    artifact** (see §6).

## 3. Version history

| Version | Content |
|---|---|
| 0.8–0.12 | District map, destructible voxel walls (cells), furnished interiors, textures, picture/grading settings, codes |
| 0.13 | Big City map, online quick match (royale + 1v1 duel), private groups |
| 0.14 | View distance and culling, auto resolution, biomes, battle bus, minimap, bosses with relics |
| 0.14.1–0.14.3 | Online ping work: compact packets, Frankfurt region, prediction and lag compensation, 30 Hz server, token bucket |
| 0.15 | Direct P2P play over WebRTC for private groups (`src/room.js`, `src/p2p.js`); the server only relays signalling |
| 0.16 | Big map about 10× the district (784×696 m), flats on upper storeys, decor, breakable windows you can climb through |
| 0.17 | Bosses VIS/IGNIS/NOEMA/ENTROPIA/NULL with relics; smarter bots; quake, rift, cataclysm effects |
| 0.18 | Wardrobe (COSMETICS tab) and battle pass: 30 free tiers, 250 XP per tier |
| 0.19 | SKILLS tab: coins buy ranks in STRENGTH and MOBILITY; CYBER STRIKE, MOMENTUM, DASH, faster sprint recharge |
| 0.20.1 | C4 remote charge and the solo debug sandbox (see §7.1) |
| **0.20** | **Remake stage 1: the whole world re-rendered (PBR surfaces, sky IBL, procedural roofs, nature, 3D grass, rubble) and drawn only where visible (occlusion, storey and range culling, chunking, single-sided models). Client-only: no protocol or server change** |

## 4. Code map (`src/`)

| File | Role |
|---|---|
| `simulation.js` (≈1.7k lines) | Authoritative `Arena`: players, Rapier physics, weapons, melee, projectiles, `blast()`, damage, bot AI (`botInput`), storm, bus, emotes, dash, perks, `snapshot()`, `collapse()`, `collapseStorey()`, `breakObstacle()`, `hitCells()` |
| `world.js` | Deterministic map generation: `createWorld(seed, size)`, `MAP_SIZES` (district, city), blocks and roads, buildings and wall panels, window glazing (`glaze`), flats, biomes (`wild()`), `LAIRS`, `seededRandom` |
| `interiors.js` | Furnishing per building type; `apartmentPlan(b)` and `furnishFlat` for upper storeys |
| `cells.js` / `destruction.js` | Voxel wall cells (≈0.4 m): `cellGrid`, `cellCenter`, `cellBox`, `cellRects`, carving, `rubbleFor`, `collapseParts`, `structure`/`storeyStructure`; destruction lists mirrored to clients |
| `raycast.js`, `spatial.js`, `navigation.js`, `terrain.js` | Rays through the obstacle grid (holes, windows), nav grid, terrain height and hills |
| `bosses.js` / `boss-view.js` | Boss AI, relics and abilities / boss rendering (Quaternius RobotExpressive rig, recoloured) and the battle bus |
| `render.js` (≈1.4k lines) | Three.js view: scene, lights, fog, sky, environment map, people (Quaternius rigs), first-person weapon, cosmetics, camera, `event()`, `syncWorld()`, `update()`, `setQuality()`, `precompile()`, loot views |
| `scenery.js` | Instanced city scenery: `CulledBatch` (instances sorted by visibility group; only visible groups are uploaded), wall panels with facade bands/plinths, damaged walls as cell layers, windows (frames, sills, lintels, glass, curtains), doors, furniture, stairs, `hidePanel/hideDecor/hideProp`, `breakRoof`, `dropRoof`, `collapseStorey`, `collapse` |
| `culling.js` | `Culler`: visibility groups (building shell, building detail, one storey's contents, 16 m outdoor cells), frustum widened by the sun shadow, 720-bin occlusion horizon of intact buildings with door/window gaps, inside-building occluder, `hides()` point test for characters and loot, `markDamaged()` |
| `materials.js` | Surfaces: `detailMaterial` (triplanar PBR in world space; `box`, `ceiling`, `interior` variants; lite path for Fast graphics), `uvMaterial`, ground (`makeGround`, `groundChunks`), `makeSky` with clouds, `makeEnvironment` (PMREM), `makeWater`, `glassMaterial`, `foliageMaterial`, `kitMaterial`, `carMaterial`, `streetMaterial`, `WORLD` (time, wind, sun), `setSurfaceQuality` |
| `roofs.js` | Procedural roofs per building category (gable, hip, flat with parapet and rooftop plant, shed, saw-tooth), chimneys and smokestacks, merged per 128 m region; `RoofField.hide(id)` and `copy(b)` for the falling roof |
| `nature.js` | Procedural broadleaf and pine trees, bushes, ferns, flowers, reeds, rocks, cacti, logs, hay bales as culled batches; `Nature.slots`, `hide(prop)` |
| `grass.js` | Instanced 3D grass patches around the camera: density mask from parks, wind in the vertex shader, bending around players |
| `chests.js`, `rubble.js` | Instanced chest rendering / rubble heap geometry of a collapsed building |
| `effects.js` | Particle pools: tracers, explosions, debris cells, shockwave rings, quake, rift, cataclysm, crit, dust, glass, fire |
| `assets.js` | Model and texture loading, `TEXTURES` table (colour, `_n`, `_arm` per set), `FOLIAGE` cards, texture-quality setting; loaded models are single-sided (`T.FrontSide`) except the glider |
| `cosmetics.js` | Cosmetics catalogue, `appearance()` / `pack()`, profile v2, battle pass |
| `skills.js` | Skill tree, `perks()`, `packSkills()` / `unpackSkills()`, `buyRank()` |
| `items.js`, `catalog.js` | Weapons (17), rarities, gear (jetpack, glider), loot tables, building types |
| `main.js` (≈1.8k lines) | App, UI, input, solo loop, online client (prediction), lobby tabs (PLAY, INVENTORY, COSMETICS, SKILLS, INFO), HUD, codes |
| `room.js`, `p2p.js` | Host-in-browser rooms and WebRTC links |
| `minimap.js`, `grading.js`, `sdk.js`, `party.js` | Minimap, colour grading, CrazyGames SDK, room codes |
| `style.css`, `index.html` | All UI markup and styles (INFO tab holds the patch notes) |
| `server.mjs` | WebSocket server: quick-match queues, parties, 30 Hz rooms, compact broadcast, signalling, `/health` |

### Network protocol

- Client → server: `input`, `ping`, `appearance`, `loadout`, `skills`, `start`.
- Server → client: `welcome`, `state` (shared state plus `self.slots`), `pong`, `error`.
- Cosmetics travel packed in `cosmetics`, perks in `skills`, dash state in `dashCd`.
- **0.20 changed no protocol field and no simulation file** — it is a pure client-render release.

## 5. Commands and tooling

```bash
npm ci
npm test        # 117 tests pass on master (0.20)
npx vite --port 5173 --host 127.0.0.1    # dev server; restart it when curl returns 000
npx vite build  # production build into dist/
```

### Headless screenshots (development only)

- `scripts/play-headless.mjs` — Playwright + Chromium (SwiftShader) at `/opt/pw-browsers`.
  `node scripts/play-headless.mjs ./script.mjs 1280 720 0`, where the script default-exports `async (page) => {…}`.
  `Q=fast|quality` sets the graphics preset (default fast).
- `scripts/shots.mjs` + `scripts/safe-run.sh` — the working recipe:
  ```bash
  SHOTS='[{"name":"street","x":46,"z":-10,"a":3.5,"p":0.02,"bots":false}]' scripts/safe-run.sh ./shots.mjs 800 450 shots.log
  ```
  It stops the game's rAF loop, renders frames by hand, reads the frame back with `readPixels` and writes
  `shots/<name>.png`; a watchdog kills Chromium before the sandbox runs out of memory (`WD=<MB>` sets the floor).
  Shot fields: `x`, `z` (metres), `y` (null = ground), `a` (yaw), `p` (pitch), `slot`, `bots:false` (parks bots far away),
  `frames`, `dt`, `setup` (JS run first with `P, sim, view`). `MODE=classic|royale|royale-city|survival`.
- Control goes through the dev-only hook `window.__prida = {sim, state, view, socket, latency, selectSlot, setLook}`.

**Pitfalls learned the hard way (do not repeat them):**

1. `page.screenshot()` on a SwiftShader canvas needs gigabytes and crashes the browser — always use `readPixels`.
2. Take **one shot per browser session**: SwiftShader keeps every compiled shader (a city view ≈3 GB).
3. Never `pkill -f play-headless` (it matches your own shell) — use `pkill -9 -f "[h]eadless_shell"`.
4. In the harness the frame loop and keyboard often do not advance; drive logic with `sim.input(...)` + `sim.step()`.
5. The **production build has no `window.__prida`** (dev-only hook), so the harness cannot drive `dist/`; test gameplay
   on the dev server and only check that the built page boots (menu appears) and starts a match.
6. With rendering stubbed, instance-buffer uploads accumulate as update ranges. Never call `clearUpdateRanges()`
   outside a full refill — see the bug in §7.
7. GLSL reserved words: `patch` is reserved (renamed to `groundPatch`).

### Build the playable Claude artifact

1. `VITE_MODEL_EXT=wasm npx vite build --outDir <tmp>/dist-artifact --emptyOutDir`
2. Rename `models/*.glb` → `*.wasm` (the artifact host refuses `.glb`).
3. Build the page: `<title>`, `theme-color` meta, the icon `<link>`, the built `<link rel=stylesheet …>`, then the
   **body** of the built `index.html`, then `<script type="module" crossorigin src="./assets/index-*.js"></script>`.
   (The artifact host adds doctype/html/head itself, so the file carries none of them.)
4. Publish to https://claude.ai/artifact/SaUVdhe3929UxBwJQy1ChU with the new `assets/index-*.js` (and `.css` if its
   hash changed) and any changed `textures/*`. The Artifact tool needs a `read` of the artifact first; files not passed
   are kept, `null` removes one.

### Deploy

The user commits the changed files on GitHub; Render builds the Dockerfile (`npm ci`, `npm run build && npm prune`,
`node server.mjs`).

## 6. The user's request: the 4-stage remake (0.20–0.23)

Translated from his message:

- Remodel everything in one realistic, detailed style: bots and players must not look cartoonish; bosses must not look
  like big robots.
- Every surface (walls, cars, objects) gets textures with normal and reflection maps. Real bricks, real 3D grass instead
  of a flat green texture.
- Optimisation: render only what the player sees — nothing behind a wall, no back faces.
- Full animation pass: several boss attacks each with its own animation; reloads (magazine out, thrown away, new one in);
  running with visible body motion and camera shake; jetpack, glider, jumping out of the bus — everything.
- Particles: real brass casings instead of cubes, muzzle fire.
- Gameplay: chests in varied places with different rarities and fewer of them; a more atmospheric bus flight with a jump
  animation and textures; weak weapons must not knock whole cubes out of buildings — instead the cube resolution rises
  locally and a crater appears; more weapons with special mechanics; real flats and corridors in the houses.
- Added in the same message: more interior (a lift, doors that open, and so on), an **interface like Fortnite's**, a
  **friends system**, and **cosmetics previewed on the character in the inventory** (not just a colour swatch).
- "Do it step by step, split everything into 4 equal stages."

| Stage | Scope | State |
|---|---|---|
| **1 (0.20) — World surfaces and performance** | PBR surfaces, real bricks, 3D grass, reflections, roofs, nature, occlusion and back-face culling | **done — §7** |
| **2 (0.21) — Models and lobby** | Realistic characters and bots, new boss creatures (not the robot rig), more detailed weapons/bus/cars in one style; Fortnite-style lobby with a 3D character on a stage and cosmetics previewed on the model | to do — §8 |
| **3 (0.22) — Animation, particles, HUD** | Reload with the magazine thrown out, running body motion and camera bob, jetpack/glider/bus-jump animations, several boss attacks, brass casings and muzzle flames; Fortnite-style in-match HUD | to do — §9 |
| **4 (0.23) — Gameplay and interiors** | Fewer chests in varied places with rarity tiers, atmospheric bus, local crater damage instead of whole cubes, new special weapons, real flats and corridors, lifts, doors that open, friends system | to do — §10 |

## 7. Stage 1 (0.20): everything that was done

Released on `master` (commits `153b781`, `9f10d17`, `6578da8`, `fa005ba`, `2def0b5`, `0e009c1`). 95 files changed
since 0.19 (`git diff --name-only 0da51cc master`; `0da51cc` is the 0.19 release commit).
`npm test` → 117 pass. Production build ≈3.17 MB JS (gzip 1.11 MB), `dist/` 15 MB.

### Textures and credits

- 22 CC0 **Poly Haven** sets downloaded at 1K and resized to 512 px JPEG by `scripts/fetch-textures.py`:
  `<name>.jpg` (colour), `<name>_n.jpg` (OpenGL normal), `<name>_arm.jpg` (AO / roughness / metalness). ≈3.4 MB total.
  bricks←brick_4, plaster←painted_plaster_wall, concrete←brushed_concrete, asphalt←asphalt_02,
  paving←square_brick_paving, grass←forrest_ground_01, dirt←brown_mud_leaves_01, sand←coast_sand_01,
  tiles←floor_tiles_06, wood←laminate_floor_02, roof←grey_roof_tiles_02, metal←metal_plate, bark←bark_brown_02,
  rock←rock_boulder_dry, claytiles←clay_roof_tiles_02, corrugated←corrugated_iron_02, gravel←tarred_gravel,
  fabric←rough_linen, oak←oak_veneer_01, panels←concrete_wall_008, sidewalk←concrete_pavement, pinebark←pine_bark.
- Foliage cards `leaves.webp` and `needles.webp` composed from ambientCG **LeafSet024** and **LeafSet019** by
  `scripts/make-foliage.py` (alpha-tested twigs, transparent pixels filled with the average leaf colour).
- `public/ASSET-CREDITS.md` updated (Poly Haven section, ambientCG leaf section, note that the Kenney city-kit building
  models are no longer drawn — only their proportions are still used by `src/building-fit.js`).

### Materials (`materials.js`)

- `detailMaterial(name, color, {strength, roughness, key, ceiling, box, metalness, env, albedo, interior})`:
  world-space **triplanar PBR** with Golus whiteout normal blending, AO from `arm.r`, roughness from `arm.g`,
  metalness from `arm.b`; a `box` mode picks the dominant axis (cheaper, for boxes); `interior` paints the inside face
  of an exterior wall as plaster using a per-instance `aOut` attribute; `ceiling` variant for slabs.
  Materials are cached by all parameters, and share the program cache key `pbr` (shader programs went 112 → 76).
- Fast graphics (`setSurfaceQuality`, `PRIDA_LITE` define): one texture sample, no normal/ARM maps, keeps the
  material roughness via `dArmMix`.
- `uvMaterial(name, {roughness, metalness, env})` for UV-mapped models, ARM feeding ao/roughness/metalness maps.
- `makeSky(capture)` with procedural clouds (zenith 0.10/0.28/0.62, horizon 0.50/0.64/0.80, cover smoothstep(0.42,0.7))
  and `makeEnvironment(renderer)` (PMREM) → `scene.environment`: glass, cars, metal and water reflect the sky.
- `glassMaterial()` (Fresnel alpha, double-sided), `foliageMaterial(kind, color)` (wind sway attribute, translucency,
  canopy ambient), `makeWater`, `kitMaterial`, `carMaterial`, `streetMaterial`.
- Ground: `makeGround` (terrain shader with grass/sand/dirt noise mixing plus normal maps) and `groundChunks(map, 48)`
  — the ground is split into 96 m chunks so off-screen chunks are frustum-culled.

### Buildings, roofs, windows, interiors

- The Kenney city-kit building models are **no longer loaded**. Facades are chosen per category
  (`bricks`, `plaster`, `panels`) and get bands, plinths, sills and lintels; interiors are painted plaster.
- `roofs.js`: procedural roofs per category — gable/hip with clay or slate tiles for homes, flat roofs with parapets and
  rooftop plant, shed and saw-tooth factory roofs, chimneys, smokestacks on industry. Merged per 128 m region,
  `hide(id)` collapses a building's roof to degenerate triangles, `copy(b)` makes the falling copy.
- Windows: frames (4 colours), sills, lintels, reflective glass and curtains as separate instanced batches;
  breaking the wall around a window shatters its pane.

### Nature, grass, rubble

- `nature.js`: procedural broadleaf trees (trunk + branches + leaf cards), pines (whorls of needle sprays), bushes,
  ferns, flowers, reeds, rocks (noise-displaced icospheres), cacti, logs, hay bales — all instanced and destructible
  (`Nature.slots` maps a prop id to its instances).
- `grass.js`: instanced grass clumps in tiles around the camera, density mask built from parks (never on roads, under
  buildings, in water or in the desert), wind in the vertex shader, bending away from players, lighter in Fast mode.
- `rubble.js` (new in the last commit): a collapsed building leaves craggy mounds of broken masonry (noise-displaced
  icospheres flattened at the ground) littered with wall blocks, tilted floor slabs and bent reinforcing bars, merged
  into two meshes per building (rock-textured mounds, concrete-textured pieces) with vertex colours.

### Visibility and performance (`culling.js`, `scenery.js`, `render.js`)

- Every instance belongs to a **visibility group**: a building's shell, its small detail (frames, sills, doors), the
  contents of one storey of one building, or a 16 m outdoor cell. `CulledBatch` keeps the full list on the CPU and
  uploads only the visible groups' instances.
- A group is drawn when it is in range (55 m for furniture, 110 m for small detail, view distance otherwise), inside the
  frustum **widened by 28°** and swept along its sun shadow, and not hidden by the **occlusion horizon**: 720 bins
  (half a degree) filled from the footprints of intact buildings, with see-through gaps where a door or window lines up
  with one on the opposite wall. Standing inside a building, its own walls become the occluder.
- Rooms are skipped from below (from the street you only see ceilings), and a damaged building stops occluding
  (`markDamaged`) so you can see through its holes.
- Static ground in 96 m chunks, static boxes and roofs in 128 m regions (smaller chunks made draw calls explode).
- Loaded models are `FrontSide` (except the glider); the bus paint/trim/glass are single-sided and glossy.
- Measured with the harness: district street view **1.64 M → 171 k triangles**; city avenue ≈583 k triangles and
  ≈390 draw calls; culling costs 1–9 ms when the camera moves; interior view ≈338 k triangles.

### Bugs found and fixed while testing

1. **Instance hides dropped each other's uploads** — `CulledBatch.hide()`/`tint()` called `clearUpdateRanges()` before
   adding their own range, so when several items were hidden in one frame (a collapse hides dozens) only the last one
   reached the GPU, and a pending full refill was discarded. Verified by a destruction run: after a building collapsed,
   the furniture of a *different* building vanished. Fixed (ranges only add up now) and covered by a test.
2. GLSL reserved word `patch` → `groundPatch`.
3. Roof winding errors (fascia, gable pentagons); foliage was dark because normals were flipped for back faces;
   clouds were invisible until the frequency/threshold were raised; too many shader programs (shared `pbr` key).
4. Pre-cut stairwell slabs wrongly marked buildings as damaged (an `initial` flag now distinguishes them).
5. Draw calls exploded with 64 m chunks → 128 m regions.

### Tests added

`tests/world-render.test.mjs` (9 tests): roof bounds/styles/hide/copy, culling behind an intact building, a damaged
building no longer hiding things, a sightline through two aligned doors, `CulledBatch` refills and hides, the grass
mask, every destructible prop having instances to hide, and buffer update ranges surviving several hides.

### Release artefacts of this stage

- `index.html` INFO tab has the "What's new · PRIDA 0.20" note; the lobby foot shows `0.20 · FPS`; the credit line now
  reads "Models by Kenney and Quaternius, textures from Poly Haven and ambientCG (all CC0)".
- `package.json` version 0.20.0. README has a "World rendering and performance (0.20)" section. `HANDOFF.md` updated.
- Zips delivered to the user: **PRIDA-0.20-github-update.zip** (95 changed files with folder paths, one GitHub upload)
  and **PRIDA-0.20-full.zip** (whole project with git history, 16 MB after `git gc`).
- Artifact republished: https://claude.ai/artifact/SaUVdhe3929UxBwJQy1ChU — version 15, bundle
  `assets/index-DAQZ5QZH.js`, CSS `assets/index-CaVZoKFU.css`, all 68 texture files, old bundles removed.

### Small leftovers from stage 1

- The published artifact (version 15) was **not opened in a browser by a human yet** — worth a quick check
  (lobby → PLAY SOLO → the world loads with textures, grass and roofs).
- Wall debris is still white cubes (`effects.js` `cells`) — stage 3/4 replaces them with chunks and craters.
- Kenney furniture and cars are still the cartoon kits — stage 2 retextures or replaces them.
- `public/models/{suburban,commercial,industrial}-*.glb` (1.5 MB, 30 files) are no longer loaded and could be deleted
  from the repo (deleting them needs the GitHub web UI, so it was left alone).
- Grass density on the Big City map was only spot-checked; if frames drop on weak phones, lower `GrassField` density in
  lite mode.

## 7.1. Version 0.20.1: C4 charge and the debug sandbox (extra request, done)

- **C4 (`WEAPONS[17]`, model `c4`)**: a power weapon with `projectile: 'c4'`, `sticky: true`, `charges: 4`,
  damage 155, radius 7.5, magazine 1 and 4 in reserve. Fire throws it; on impact `Arena.placeCharge()` turns the
  projectile into an entry of `Arena.charges` (id, owner, position, surface normal), the fifth charge drops the oldest.
  The new one-shot input `detonate` (client: right mouse button, or the ⊕ touch button, while a charge is held) calls
  `Arena.detonate(p)`, which blasts every charge of that player. Charges of a dead or departed owner are defused
  (`stepCharges`), bots have no detonator so theirs go off on a 2.2 s fuse and `botSlot` gives sticky weapons −40, so
  bots rarely hold one. The charges list travels in the snapshot, so online clients see it; `render.js`
  `updateCharges()` draws the model lying on the surface with a blinking lamp, `projectileView` tumbles it in flight.
  Model and icon: `scripts/procedural-models.js` `c4()` → `public/models/c4.glb`, `public/icons/c4.png` (built by
  `scripts/build-weapon-assets.mjs`).
- **Debug sandbox (`mode: 'debug'`)**: a solo lobby mode ("Debug · sandbox"). No storm (no zone), the clock does not
  run down, the match never ends by itself, respawns on, `cheated = true` so no coins or XP. `Arena.debugGive(id, {weapon,
  rarity, gear, medkits, armor, ammo, heal})` and `Arena.debugBots(count)` only work in this mode; the server builds
  arenas from its own MODES table, so it can never run it. The client opens `#debugPanel` with **J** or the DEBUG MENU
  button: a grid of all 18 weapons (rarity chosen in a select), gear, supplies, target bots and the flight / god /
  infinite-ammo toggles.
- Tests: `tests/sandbox.test.mjs` (6 tests) plus the updated weapon-count and damage tests.

## 8. Stage 2 (0.21) — models and lobby (next to do)

**Goal:** everything that is still cartoonish becomes one realistic style, and the lobby looks like Fortnite's.

1. **Characters (players and bots).** Current rigs are Quaternius Toon Shooter (`soldier.glb`, `hazmat.glb`,
   `scout.glb`) with 17 clips (Death, Duck, HitReact, Idle, Idle_Shoot, Jump, Jump_Idle, Jump_Land, No, Punch, Run,
   Run_Gun, Run_Shoot, Walk, Walk_Shoot, Wave, Yes) — `render.js` looks these names up.
   - Options: Quaternius **Universal Base Characters** + **Universal Animation Library** (CC0) — better proportions and
     a bigger clip set; or keep the rigs and rebuild the meshes/materials (7.5-head proportions, smaller head, real
     boots, vest, pouches) with `uvMaterial` and fabric/leather ARM maps.
   - Avoid Mixamo files (redistribution restricted). Keep the clip-name mapping in one table so `render.js` keeps working.
2. **Bosses.** Replace the RobotExpressive rig with five distinct creatures (VIS strength colossus, IGNIS fire golem,
   NOEMA mind oracle, ENTROPIA chaos herald, NULL void warden). CC0 rigged monsters are rare, so procedural
   mesh-authored bodies (the `nature.js` approach: merged primitives, vertex colours, PBR surfaces) with a small
   runtime skeleton are the realistic path. Keep `bosses.js` ability timings untouched.
3. **Weapons, cars, furniture, bus.** Retexture the Kenney kits with `uvMaterial` + ARM maps and darker, less saturated
   palettes; add detail to the held weapons (sights, rails, magazines — the magazine mesh is needed by stage 3 anyway);
   rebuild the battle bus with proper materials and an interior.
4. **Fortnite-style lobby.** A 3D character stage in the lobby (own small scene, soft key light, slow turntable),
   the INVENTORY/COSMETICS tabs showing the selected skin, accessory, weapon finish and emote **on the model**, item
   cards in a grid with rarity borders and a preview on hover/tap. Files: `index.html`, `src/style.css`, `src/main.js`,
   a new `src/lobby-view.js` (reuse `cosmetics.js` and the character loading code from `render.js`).
5. Keep the English-only rule, run `npm test`, republish the artifact, and ship both zips.

## 9. Stage 3 (0.22) — animation, particles, HUD

1. **Reload** with the magazine really leaving the weapon: eject, throw (a small falling mag prop with gravity and a
   bounce), take a new one, insert, charge. Per weapon family (rifle/SMG, shotgun shells, revolver cylinder, launcher,
   crossbow, dagger). Procedural, in the first-person weapon rig in `render.js`.
2. **Body and camera motion:** visible legs/arms while running, footstep-synced camera bob and a shake that scales with
   speed and landing force; separate poses for sprint, aim, heal, emote.
3. **Jetpack, glider, bus jump:** real animations for the character and the camera (lean, thrust, glide pose, the jump
   out of the bus with the hatch and a free-fall pose).
4. **Boss attacks:** each boss gets several attacks with their own animations and telegraphs, matching the ability
   timings in `bosses.js`.
5. **Particles (`effects.js`):** brass casings that spin, bounce and fade (instanced, pooled), muzzle flash (a short
   flash quad plus a light), smoke wisps, better impact sparks and debris chunks with textures instead of white cubes.
6. **Fortnite-style HUD:** rebuilt layout in `index.html`/`style.css` — weapon slots with rarity borders bottom-right,
   health and shield bars bottom-centre, minimap top-right, kill feed, hit markers, damage numbers.

## 10. Stage 4 (0.23) — gameplay and interiors

1. **Chests:** fewer of them, placed in varied spots (roofs, basements, flats, park corners), with visible rarity tiers
   (`items.js`, `world.js`, `chests.js`).
2. **Bus:** atmospheric flight — interior, engine sound, the map below, a proper jump-out animation and textures.
3. **Crater damage:** weak weapons must not delete 0.4 m cubes. Plan: keep the cell grid, but for small hits subdivide
   the hit cell into a finer sub-grid (`cells.js`) and carve a rounded crater with a dark scorched rim; only heavy
   weapons remove whole cells. The simulation and the destruction lists must stay compact for the network.
4. **New special weapons** (`items.js`, `simulation.js`): e.g. sticky grenades, a railgun that pierces walls, a drone,
   a shield wall — each with its own mechanic, balanced against the existing 17.
5. **Real flats and corridors:** `interiors.js` — a corridor per storey with numbered flat doors, a stairwell core,
   **doors that open** (door state in `simulation.js` with a collider that moves) and a **lift** (a moving platform with
   call buttons, floors and a door). This is the biggest engineering item of the stage: the physics platform and the
   network state for it do not exist yet.
6. **Friends system:** friend codes (already have room codes in `party.js`), a friend list stored per device, online
   status and "invite to group" through the existing WebSocket server (`server.mjs`). No accounts, no secrets in the
   client, no invented server addresses.

## 11. Research notes and sources

- **Poly Haven** (CC0) is reachable with `curl -A "Mozilla/5.0"`; Python `urllib` gets 403. API:
  `https://api.polyhaven.com/files/<id>`. It also has CC0 models (grass_medium_01/02, fir_tree_01, fire_hydrant,
  barrels, furniture, `modular_urban_apartments_facade`) — photogrammetry, heavy, would need decimating and LODs.
- **ambientCG** (CC0): textures and leaf sets, `https://ambientcg.com`.
- **Quaternius** (CC0): Toon Shooter Game Kit (current characters and weapons), RobotExpressive (current bosses),
  Universal Base Characters + Universal Animation Library (candidates for stage 2).
- **Kenney** (CC0): city kits (buildings no longer drawn), furniture kit, car kit, road kit, blaster kit.
- Nothing is fetched at runtime: every asset is in `public/`.

## 12. State right now

- Git: **github.com/scoof-pri/prida**, branch `master`, version 0.20.1, 123 tests pass, build OK. The full zip carries
  the whole `.git` history, so `git log`, `git diff 0da51cc master` and branches work in a new session.
- The user has both zips; he uploads the update zip to GitHub through the web UI, Render redeploys automatically.
- The playable artifact is at version 15 (0.20 world).
- Next message to the user should start **stage 2 (0.21)** and follow the workflow in §2.
