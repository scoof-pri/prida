// The C4 demolition charge and the solo debug sandbox (mode 'debug').
import test from 'node:test';
import assert from 'node:assert/strict';
import { Arena, initPhysics } from '../src/simulation.js';
import { WEAPONS } from '../src/world.js';
import { makeItem } from '../src/items.js';
await initPhysics();
const C4 = WEAPONS.findIndex((w) => w.sticky);
function place(a, p, x, z, y = 0.02) {
  Object.assign(p, { x, z, y, shield: 0, cooldown: 0, vy: 0 });
  const body = a.bodies.get(p.id).body;
  body.setTranslation({ x, y: y + 0.84, z }, true);
  body.setNextKinematicTranslation({ x, y: y + 0.84, z });
  a.world.step();
}
// Arms the player with charges and throws one, letting it land.
function throwCharge(a, p, pitch = -0.2) {
  p.slots[1] = makeItem(C4);
  p.slot = 1;
  a.syncHeld(p);
  p.pitch = pitch;
  p.cooldown = 0;
  a.shoot(p);
  for (let i = 0; i < 120 && a.projectiles.length; i++) a.stepProjectiles(1 / 60);
  return a.charges[a.charges.length - 1];
}
test('the C4 charge is thrown, sticks where it lands and only goes off on the detonator', () => {
  const a = new Arena({ random: () => 0.5 }),
    p = a.addPlayer('p', 'P'),
    q = a.addPlayer('q', 'Q');
  place(a, p, 0, 0);
  place(a, q, 0, 6);
  p.angle = 0;
  const c = throwCharge(a, p);
  assert.ok(c, 'the charge stuck to the world');
  assert.equal(a.projectiles.length, 0);
  assert.equal(q.hp, 100, 'nothing goes off by itself');
  assert.ok(Math.hypot(c.x - p.x, c.z - p.z) > 1, 'it flew away from the thrower');
  assert.ok(a.snapshot().charges.length === 1, 'clients are told about it');
  assert.ok(a.detonate(p));
  assert.ok(q.hp < 100, 'the blast hurts whoever stands beside it');
  assert.equal(a.charges.length, 0);
  assert.equal(a.detonate(p), false, 'nothing left to set off');
  a.dispose();
});
test('only the newest charges stay armed, and a dead thrower defuses their own', () => {
  const a = new Arena({ random: () => 0.5 }),
    p = a.addPlayer('p', 'P');
  place(a, p, 0, 0);
  p.cheats.god = true;
  const max = WEAPONS[C4].charges;
  for (let i = 0; i < max + 2; i++) {
    p.angle = (i / (max + 2)) * Math.PI * 2;
    throwCharge(a, p);
  }
  assert.equal(a.charges.length, max, 'placing one more drops the oldest');
  p.hp = 0;
  a.stepCharges(1 / 60);
  assert.equal(a.charges.length, 0, 'a dead thrower leaves no live charges');
  a.dispose();
});
test('bots have no detonator button, so their charges run on a fuse', () => {
  const a = new Arena({ random: () => 0.5 }),
    b = a.addPlayer('b', 'BOT', true);
  place(a, b, 0, 0);
  b.angle = 0;
  throwCharge(a, b);
  assert.equal(a.charges.length, 1);
  for (let i = 0; i < 200 && a.charges.length; i++) a.stepCharges(1 / 60);
  assert.equal(a.charges.length, 0, 'it went off on its own');
  a.dispose();
});
test('the detonate input sets charges off through the normal step, whatever is held', () => {
  const a = new Arena({ random: () => 0.5 }),
    p = a.addPlayer('p', 'P');
  place(a, p, 0, 0);
  p.cheats.god = true;
  p.angle = 0;
  throwCharge(a, p);
  a.equip(p, 0); // back to the melee slot
  a.input('p', { angle: 0, detonate: true });
  a.step();
  assert.equal(a.charges.length, 0);
  a.dispose();
});
test('the debug sandbox has no storm, no timer and no rewards', () => {
  const a = new Arena({ mode: 'debug', bots: 0 }),
    p = a.addPlayer('you', 'YOU');
  assert.equal(a.mode, 'debug');
  assert.equal(a.cheated, true, 'rewards are off, like with any cheat');
  assert.equal(a.snapshot().zone, null, 'no shrinking zone');
  assert.equal(a.respawns, true);
  const time = a.time;
  place(a, p, 0, 0);
  for (let i = 0; i < 60; i++) a.step();
  assert.equal(a.time, time, 'the clock does not run down');
  assert.equal(a.winner, null, 'the match never ends by itself');
  a.dispose();
});
test('the debug menu hands out items and target bots, and does nothing in the other modes', () => {
  const a = new Arena({ mode: 'debug', bots: 0 }),
    p = a.addPlayer('you', 'YOU');
  place(a, p, 0, 0);
  assert.ok(a.debugGive('you', { weapon: C4, rarity: 4, ammo: true }));
  const item = p.slots.find((s) => s && s.w === C4);
  assert.ok(item && item.r === 4, 'a legendary charge is in the inventory');
  assert.ok(a.debugGive('you', { medkits: 3, armor: 100, gear: 'jetpack' }));
  assert.equal(p.medkits >= 3, true);
  assert.equal(p.armor, 100);
  assert.equal(p.gear.id, 'jetpack');
  assert.equal(a.debugBots(2), 2);
  assert.equal(a.debugBots(0), 0);
  a.dispose();
  // The same calls are refused in a normal match (the server never runs 'debug' at all).
  const b = new Arena({ mode: 'classic', bots: 0 }),
    q = b.addPlayer('you', 'YOU');
  assert.equal(b.debugGive('you', { weapon: C4 }), false);
  assert.equal(b.debugBots(3), 0);
  assert.equal(q.slots.some((s) => s && s.w === C4), false);
  b.dispose();
});
